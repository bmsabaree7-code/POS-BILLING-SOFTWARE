# RUBIX POS activation and security notes

- The same owner activation credentials can activate separate PCs. Each PC writes its own machine-bound license file under `%APPDATA%\\RUBIXPOS`.
- Local license integrity checks and a short failed-attempt throttle reduce accidental tampering and repeated guessing.
- **Important limitation:** offline desktop software cannot keep an embedded secret fully secret. This local mechanism is not equivalent to a strong online commercial license server.
- For production distribution, use a hosted HTTPS license API with server-side key verification, per-customer/per-device activation records, signed short-lived license responses (Ed25519), TLS certificate validation, request rate limiting, audit logs, revocation, and secret storage only on the server. Never embed server private keys or API secrets in the desktop client.
- Login credentials in this legacy app still use its existing SHA-256 database format for compatibility. Before commercial deployment, migrate passwords to Argon2id or PBKDF2 with unique salts and add account-level login throttling.
