@echo off
setlocal
cd /d "%~dp0"
title RUBIX POS - EXE Builder
where py >nul 2>nul
if not errorlevel 1 (set "PY=py -3") else (
  where python >nul 2>nul
  if errorlevel 1 (echo Python not found. Install Python 3.11/3.12 and enable PATH.& pause& exit /b 1)
  set "PY=python"
)
%PY% -m pip install --upgrade pip
%PY% -m pip install -r requirements.txt
if errorlevel 1 goto :error
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist "RUBIX_POS.spec" del /q "RUBIX_POS.spec"
%PY% -m PyInstaller --noconfirm --clean --windowed --onefile --name "RUBIX_POS" --add-data "assets;assets" main.py
if errorlevel 1 goto :error
echo.
echo BUILD SUCCESS: %CD%\dist\RUBIX_POS.exe
echo Activation data and database are stored under %%APPDATA%%\RUBIXPOS
pause
exit /b 0
:error
echo EXE build failed. Review the error above.
pause
exit /b 1
