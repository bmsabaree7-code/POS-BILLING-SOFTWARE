import sys, json
from pathlib import Path
from PySide6.QtWidgets import QApplication, QDialog, QFileDialog, QMessageBox
from app.ui import MainWindow, LoginDialog, ActivationDialog, SplashScreen, THEME_CSS
from app.license import is_activated
from app.database import init_db, backup_database, database_is_valid, restore_latest_backup

APP_CONFIG_DIR = Path.home() / ".rubix_pos"
DATA_CONFIG = APP_CONFIG_DIR / "data_location.json"

def choose_data_root(app):
    """Ask once where the business database and backups should live."""
    APP_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if DATA_CONFIG.exists():
        try:
            saved = json.loads(DATA_CONFIG.read_text(encoding="utf-8")).get("data_root", "")
            if saved and Path(saved).is_dir():
                return Path(saved)
        except (OSError, ValueError, TypeError):
            pass
    QMessageBox.information(None, "Choose Data Folder", "Choose the folder where RUBIX POS will save its database, backups, invoices and exports. You will only be asked on first launch.")
    folder = QFileDialog.getExistingDirectory(None, "Select RUBIX POS Data Folder", str(Path.home() / "Documents"))
    if not folder:
        return None
    root = Path(folder).expanduser().resolve()
    try:
        root.mkdir(parents=True, exist_ok=True)
        DATA_CONFIG.write_text(json.dumps({"data_root": str(root)}, indent=2), encoding="utf-8")
    except OSError as exc:
        QMessageBox.critical(None, "Data Folder Error", f"Could not save the selected data folder:\n{exc}")
        return None
    return root

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("RUBIX POS")
    # Force a consistent light theme (dark text on white) even when Windows is in dark mode.
    from PySide6.QtGui import QPalette, QColor
    app.setStyle("Fusion")
    pal = QPalette()
    for role, col in [(QPalette.Window,"#f5efe6"),(QPalette.WindowText,"#3b2414"),(QPalette.Base,"#fffdf9"),(QPalette.AlternateBase,"#f8efe0"),
                      (QPalette.Text,"#3b2414"),(QPalette.Button,"#f6ead8"),(QPalette.ButtonText,"#3b2414"),(QPalette.ToolTipBase,"#fff8ec"),
                      (QPalette.ToolTipText,"#3b2414"),(QPalette.PlaceholderText,"#9a8068"),(QPalette.Highlight,"#8b5e3c"),(QPalette.HighlightedText,"#ffffff")]:
        pal.setColor(role, QColor(col))
    app.setPalette(pal)
    app.setStyleSheet(THEME_CSS)  # beige/brown theme for splash, login, notifications and every dialog
    base = choose_data_root(app)
    if base is None:
        return
    db = base / "database" / "pos.db"
    backups = base / "backups"
    # Recover automatically before migrations/opening the live database.
    # If recovery is impossible, preserve the damaged file and start a clean DB.
    if db.exists() and not database_is_valid(db):
        recovered = restore_latest_backup(db, backups)
        if not recovered:
            damaged = db.with_name(f"pos_corrupt_{__import__('datetime').datetime.now().strftime('%Y%m%d_%H%M%S')}.db")
            try:
                db.replace(damaged)
            except OSError:
                QMessageBox.critical(None, "Database Recovery Failed",
                    "The database is damaged and could not be moved aside. Please check folder permissions and restore from a backup.")
                return
    elif not db.exists() and any(backups.glob("pos_backup_*.db")):
        restore_latest_backup(db, backups)
    init_db(db)
    backup_database(db, backups)
    if not is_activated():
        activation = ActivationDialog()
        if activation.exec() != QDialog.Accepted:
            return
    splash = SplashScreen()
    splash.exec()
    login = LoginDialog(db)
    if login.exec() != QDialog.Accepted:
        return
    win = MainWindow(db)
    win.current_user = login.user["username"]
    win.current_role = login.user["role"]
    win.current_name = login.user["name"]
    win.build_ui()
    if login.user.get("must_change") and not win.force_password_change():
        return
    win.refresh_all()
    win.showFullScreen()  # opens full screen right after login (F11 toggles)
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
