# RUBIX POS — Windows Desktop

## Updated navigation and screens
- Activation, splash, login and main POS window open full-screen/maximized.
- The main workspace shows **POS Billing only**. Open **More** for Products / Inventory, CRM / Customers, Sales Report, Stock Report, Customer Report, Dashboard / AI Analytics, Suppliers, Purchases / Stock-In, Expenses / Finance and (Admin only) Users & Access.
- Settings & Security has been removed from the navigation.
- Sales, stock and customer reports read records from the local SQLite database and refresh with the Refresh button or the header refresh control.
- Quantity controls reset to 1 after adding a scanned item; cart row minus/plus controls change the selected cart item's quantity, limited by available stock.
- On first launch, the app asks where to store the database and business files. The choice is saved in `%USERPROFILE%\.rubix_pos\data_location.json`; the app will not ask again unless that file is removed or the selected folder is unavailable. The chosen folder contains `database\pos.db`, `backups`, exports, invoices and barcode PDFs.

## First Admin login
- Username: `RUBIX`
- Password: `A1B2C3D4`
- After login, Admin can manage staff from **More → Users & Access**, including username/password resets. After resetting a password, use that staff member's exact username and the new password on the next login.
- Roles available: **Admin, Manager, Cashier, Accountant**. There is no Super Admin role.
- New staff initially receive `ChangeMe123!`; reset it immediately after creating the account.
- Inventory includes product/barcode/category search, stock levels, minimum-stock tracking, purchase/stock-in and barcode PDF generation. USB/Bluetooth barcode scanners that type a barcode and press Enter are supported.
- More → **DATA CENTER — Export All Data** exports database tables to CSV, Excel, PDF or Word. Excel/Word export requires packages in `requirements.txt`.

## First run (Windows)
1. Install Python 3.11 or 3.12 from https://www.python.org/downloads/windows/ and enable **Add python.exe to PATH**.
2. Extract this ZIP and open the `ADVANCED_POS` folder.
3. Double-click `run_windows.bat`, or run in CMD/Terminal:
   ```bat
   py -3 -m pip install -r requirements.txt
   py -3 main.py
   ```
4. Select the data folder when prompted for the first time.
5. If activation is required, enter your valid activation key and activator name.
6. Sign in with the Admin credentials above (unless changed previously).

## Build EXE
On Windows, double-click `build_exe.bat`, or run:
```bat
py -3 -m pip install -r requirements.txt
py -3 -m PyInstaller --noconfirm --clean --windowed --onefile --name RUBIX_POS --add-data "assets;assets" main.py
```
The EXE is generated at `dist\RUBIX_POS.exe`.

## Test core database functions
```bat
py -3 test_core.py
```

## Activation note
The local activation is a convenience check, not tamper-proof commercial licensing. Keep the activation key private. Commercial deployment may require a server-signed license and separate legal/accounting review.

## UI and bill-print updates (2026-10)
- Removed the CSV dataset import option and its import workflow from the More menu.
- Kept export tools; renamed the all-data export menu item to **Export All Data**.
- Replaced the quantity spinner arrows with small, simple minus/plus buttons in POS billing. Cart rows now have minus, plus and remove controls.
- Restyled buttons to a compact neutral design; made **More** smaller and changed Refresh to a small blue refresh icon without a blue button background. Clicking it refreshes the views from SQLite.
- Bill PDF generation now uses printer-safe `Rs.` text for amounts (avoids unsupported rupee glyphs in ReportLab's built-in Helvetica font). On Windows, **PRINT BILL** asks the default PDF application's registered print handler to print; if that is unsupported, it opens the PDF for Ctrl+P. The PDF is still saved under the data folder's `exports` directory.

## POS capabilities not currently implemented (potential future features)
- True split tender: entering separate cash + UPI/card amounts and validating the combined payment.
- GST-compliant invoice configuration: business GSTIN, state/place-of-supply, HSN/SAC, CGST/SGST/IGST breakdown, tax invoice numbering rules and credit/debit notes.
- Thermal receipt printer setup, paper-size templates (58/80 mm), cash-drawer kick, barcode scale support and printer selection/testing UI.
- Cloud sync / multi-device live database, online admin dashboard, branch-to-branch stock transfers and remote staff status.
- Integrated payment gateway/UPI QR collection and automatic transaction reconciliation.
- WhatsApp/SMS/email invoice delivery, customer marketing campaigns and automated reminders.
- Supplier payment ledger/settlement, purchase returns, customer credit collection workflow and partial refunds.
- Cashier shift opening/closing, cash drawer reconciliation, end-of-day Z report and approval/PIN for high discounts/refunds.
- Automated scheduled/off-site backups with restore wizard and backup integrity checks.
- Dedicated audit-log viewer, configurable permissions per action, and stronger password hashing (current local login hash is SHA-256, which should be upgraded before production use).
- Automated UI/printing integration tests and installer/updater for non-technical Windows users.

These are not included in the current build; do not treat the current app as a complete GST/accounting or cloud POS system until the relevant features are developed and tested.


## Automatic backup and recovery

- The manual **Backup Database** menu item has been removed.
- RUBIX POS creates a consistent SQLite backup on startup, every 5 minutes while open, and when the app closes.
- Backups are stored in the selected data folder's `backups` directory. The newest 30 valid backups are retained.
- On startup, the app checks the live database. If it is missing or corrupted, it automatically attempts to restore the newest valid backup.
- If the database is corrupted and no valid backup is available, the damaged database is preserved with a `pos_corrupt_...db` name before a fresh database is created.
- Backups are local to this computer/folder. For protection against drive failure or theft, copy the data folder to an external drive or a secure cloud-sync folder.

## Premium update

**Security**
- Passwords are stored with PBKDF2-SHA256 + random salt. Old accounts are upgraded automatically at their next login.
- First login with the factory password `A1B2C3D4` forces you to choose a new one (min 8 chars, letters + numbers).
- 5 wrong logins lock the sign-in screen for 60 seconds. *More ▸ Change My Password* for everyone.
- An automatic backup is taken before every delete and CSV import.

**Billing**
- Discount in ₹ or %. Cash received → change to return. Split payment (cash + UPI/Card/Wallet).
- Customer name + loyalty points appear as you type the phone number.
- Expired product warning, overselling guard at checkout.
- Shortcuts: F2 checkout, F3 scan box, F4 hold, F6 resume, F8 clear.
- *More ▸ Store Details* sets name / address / phone / GSTIN / footer printed on every bill.

**Inventory & purchasing**
- Add / Edit / Delete on Products, Customers, Suppliers, Expenses, Users.
- Product unit + expiry date. Loss-making price warning.
- Stock-In records a real purchase bill with supplier (Cash / UPI / Bank / Credit). Credit adds to the supplier balance; PAY BALANCE reduces it.
- CSV import for Products (barcode,name,category,unit,purchase_price,selling_price,stock,min_stock,tax_rate,expiry_date) and Customers (name,phone,email,address).

Run `python test_core.py` for the automated checks.
