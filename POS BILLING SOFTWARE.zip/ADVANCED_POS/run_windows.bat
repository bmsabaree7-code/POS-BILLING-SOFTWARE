@echo off
setlocal
cd /d "%~dp0"
title RUBIX POS - Start
color 0F
where py >nul 2>nul
if not errorlevel 1 (set "PY=py -3") else (
  where python >nul 2>nul
  if errorlevel 1 (echo Python 3.11/3.12 not found. Install from python.org and tick Add Python to PATH.& pause& exit /b 1)
  set "PY=python"
)
%PY% --version
if errorlevel 1 goto :error
%PY% -m pip install --upgrade pip
%PY% -m pip install -r requirements.txt
if errorlevel 1 goto :error
%PY% main.py
if errorlevel 1 goto :error
exit /b 0
:error
echo.
echo Start failed. Read the error above.
pause
exit /b 1
