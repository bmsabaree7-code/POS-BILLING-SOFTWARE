
from PySide6.QtCore import Qt, QTimer, QDate, QSizeF, QMarginsF
from PySide6.QtGui import QFont, QPixmap, QIcon, QTextDocument, QShortcut, QKeySequence, QPageSize, QPageLayout
from PySide6.QtWidgets import *
from PySide6.QtPrintSupport import QPrinter, QPrintDialog, QPrinterInfo
from datetime import datetime, timedelta
from pathlib import Path
import sqlite3, csv, json, math, sys, hashlib, os, time
import html as _html

ASSET_ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent.parent)) / 'assets'

# ---------------------------------------------------------------------------
# One beige / brown theme for the WHOLE application (windows, dialogs, menus,
# notifications, calendars, tables). Dark brown text on beige/white surfaces and
# cream text on dark-brown surfaces, so nothing is ever black-on-black.
# ---------------------------------------------------------------------------
THEME_CSS = """
QMainWindow{background:#f5efe6}
QWidget{font-family:"Segoe UI";color:#3b2414}
QDialog{background:#f5efe6}
#page{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #faf5ec,stop:.55 #f3e8d6,stop:1 #ecdcc3)}
#header{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #3b2414,stop:.5 #5a3a22,stop:1 #8b5e3c);border-radius:18px}
#heroTitle{color:#fff7ea;font-size:25px;font-weight:800}
QTabWidget::pane{border:1px solid #d9c3a5;border-radius:14px;background:#fffaf2}
QTabBar::tab{padding:12px 16px;margin:3px;border-radius:9px;font-weight:700;color:#6b4a2f;background:#ead9c0}
QTabBar::tab:selected{background:#6b4226;color:#fff7ea}
QPushButton{padding:7px 11px;border:1px solid #cdb08a;border-radius:6px;color:#3b2414;background:#f6ead8;font-weight:600}
QPushButton:hover{background:#ecd7b8;border-color:#a9754b}
QPushButton:pressed{background:#dfc39c}
#refreshButton{background:transparent;color:#f0c98f;border:0;padding:0;font-size:22px;font-weight:700;min-width:24px;max-width:24px;min-height:24px;max-height:24px}
#refreshButton:hover{color:#ffffff;background:rgba(255,255,255,40);border-radius:12px}
#moreButton{background:#fff7ea;color:#3b2414;padding:5px 9px;border:1px solid #cdb08a;border-radius:6px}
#moreButton:hover{background:#f1dfc3}
#signoutButton{background:#fff1e6;color:#9a3412;padding:6px 10px;border:1px solid #f0c9a8}
#signoutButton:hover{background:#fde4cf}
QLineEdit,QTextEdit,QComboBox,QDoubleSpinBox,QSpinBox,QDateEdit{padding:7px 10px;min-height:36px;border:1px solid #d6bf9f;border-radius:9px;background:#fffdf9;color:#3b2414;selection-background-color:#8b5e3c;selection-color:#ffffff}
QLineEdit:focus,QTextEdit:focus,QComboBox:focus,QDoubleSpinBox:focus,QSpinBox:focus,QDateEdit:focus{border:2px solid #8b5e3c;color:#3b2414;background:#ffffff}
QSpinBox QLineEdit,QDoubleSpinBox QLineEdit{padding:5px 8px;min-height:28px;color:#3b2414;background:#fffdf9;selection-background-color:#8b5e3c;selection-color:#ffffff}
QCheckBox{color:#3b2414;spacing:8px}
#qtyMinus,#qtyPlus,#cartMinus,#cartPlus{padding:0;font-size:15px;font-weight:700;border:1px solid #cdb08a;border-radius:5px;background:#f6ead8;color:#4a2f1b}
#qtyMinus:hover,#qtyPlus:hover,#cartMinus:hover,#cartPlus:hover{background:#ecd7b8;border-color:#a9754b}
QComboBox QAbstractItemView{background:#fffaf2;color:#3b2414;selection-background-color:#8b5e3c;selection-color:#ffffff}
QTableWidget{background:#fffdf9;alternate-background-color:#f8efe0;color:#3b2414;gridline-color:#ead9c0;border:1px solid #e2d2b8;border-radius:10px;selection-background-color:#ead7bb;selection-color:#3b2414}
QHeaderView::section{padding:9px;font-weight:800;color:#4a2f1b;background:#ead9c0;border:0}
QTableCornerButton::section{background:#ead9c0;border:0}
QGroupBox{color:#4a2f1b;font-weight:800;border:1px solid #e2d2b8;border-radius:12px;margin-top:8px;padding-top:10px;background:#fffaf2}
QGroupBox::title{subcontrol-origin:margin;left:12px;padding:0 5px}
QLabel{color:#4a2f1b}
QScrollArea{background:#fffaf2;border:0}
#invPage{background:#fffaf2}
QFrame#statCard{background:#fffdf9;border:1px solid #e2d2b8;border-radius:12px}
QLabel#statName{color:#8b6b4a;font-size:11px;font-weight:700;background:transparent}
QLabel#statValue{color:#6b4226;font-size:19px;font-weight:800;background:transparent}
QScrollBar:vertical{background:#f3e9d8;width:10px;border-radius:5px}
QScrollBar::handle:vertical{background:#c9a47a;border-radius:5px;min-height:30px}
QScrollBar:horizontal{background:#f3e9d8;height:10px;border-radius:5px}
QScrollBar::handle:horizontal{background:#c9a47a;border-radius:5px;min-width:30px}
QStatusBar{color:#4a2f1b;background:#f5efe6}
QToolTip{background:#fff8ec;color:#3b2414;border:1px solid #cdb08a;padding:4px}
QMenu{background:#fffaf2;color:#3b2414;border:1px solid #d9c3a5;border-radius:10px;padding:7px}
QMenu::item{padding:10px 18px;border-radius:7px;margin:2px;color:#3b2414}
QMenu::item:selected{background:#ead7bb;color:#3b2414;font-weight:800}
QMenu::separator{height:1px;background:#e2d2b8;margin:6px 8px}
QMessageBox,QInputDialog,QFileDialog{background:#fff8ec}
QMessageBox QLabel,QInputDialog QLabel{color:#3b2414;font-size:13px;background:transparent}
QMessageBox QLabel{min-width:300px}
QMessageBox QPushButton,QInputDialog QPushButton,QDialogButtonBox QPushButton{background:#6b4226;color:#fff7ea;border:0;border-radius:6px;padding:8px 18px;min-width:72px}
QMessageBox QPushButton:hover,QInputDialog QPushButton:hover,QDialogButtonBox QPushButton:hover{background:#8b5e3c}
QCalendarWidget QWidget{color:#3b2414;background:#fffaf2}
QCalendarWidget QAbstractItemView:enabled{color:#3b2414;background:#fffaf2;selection-background-color:#6b4226;selection-color:#ffffff}
QCalendarWidget QAbstractItemView:disabled{color:#b8a58a}
QCalendarWidget QToolButton{color:#3b2414;background:#f1e2c9;border-radius:6px;padding:4px 8px}
QSpinBox::up-button,QSpinBox::down-button,QDoubleSpinBox::up-button,QDoubleSpinBox::down-button{width:0px;height:0px;border:0px}
QSpinBox::up-arrow,QSpinBox::down-arrow,QDoubleSpinBox::up-arrow,QDoubleSpinBox::down-arrow{image:none;width:0px;height:0px}
"""


from .database import connect, backup_database
from .security import DEFAULT_ADMIN_PASSWORD, hash_password, verify_password, is_default_password, password_problem
from . import services
from .barcode import generate_code128_pdf



class ActivationDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        from .license import machine_id
        self.setWindowTitle("RUBIX POS — PC Activation")
        self.showFullScreen()
        self.setStyleSheet("""
          QDialog{background:#f5efe6} QFrame#authCard{background:#fffaf2;border:1px solid #d9c3a5;border-radius:16px}
          QLabel{color:#3b2414} QLineEdit{padding:12px 14px;border:1px solid #d6bf9f;border-radius:7px;background:#fffdf9;color:#3b2414;min-height:22px;font-size:14px}
          QLineEdit:focus{border:1px solid #8b5e3c} QPushButton{padding:12px;border:0;border-radius:7px;background:#6b4226;color:#fff7ea;font-weight:800;font-size:14px}
          QPushButton:hover{background:#8b5e3c}
        """)
        outer=QVBoxLayout(self); outer.setContentsMargins(20,20,20,20); outer.addStretch()
        card=QFrame(); card.setObjectName("authCard"); card.setFixedWidth(440)
        layout=QVBoxLayout(card); layout.setContentsMargins(34,28,34,30); layout.setSpacing(13)
        logo=QLabel(); pix=QPixmap(str(ASSET_ROOT/"rubix_logo.png"))
        if not pix.isNull(): logo.setPixmap(pix.scaled(155,62,Qt.KeepAspectRatio,Qt.SmoothTransformation))
        logo.setAlignment(Qt.AlignCenter); layout.addWidget(logo)
        title=QLabel("Activate your device"); title.setAlignment(Qt.AlignCenter); title.setStyleSheet("font-size:23px;font-weight:800;color:#1c1e21"); layout.addWidget(title)
        desc=QLabel("Enter your activation details to continue"); desc.setAlignment(Qt.AlignCenter); desc.setStyleSheet("color:#606770;font-size:12px"); layout.addWidget(desc)
        self.key=QLineEdit(); self.key.setPlaceholderText("Activation key"); self.key.setMinimumHeight(46)
        self.activator=QLineEdit(); self.activator.setPlaceholderText("Activator name"); self.activator.setMinimumHeight(46)
        layout.addWidget(self.key); layout.addWidget(self.activator)
        machine=QLabel("DEVICE ID  •  "+machine_id()[:16]); machine.setAlignment(Qt.AlignCenter); machine.setStyleSheet("color:#90949c;font-size:10px"); layout.addWidget(machine)
        self.error=QLabel(""); self.error.setWordWrap(True); self.error.setStyleSheet("color:#b42318;font-weight:600"); layout.addWidget(self.error)
        btn=QPushButton("ACTIVATE & CONTINUE"); btn.setMinimumHeight(44); btn.clicked.connect(self.do_activate); layout.addWidget(btn)
        outer.addWidget(card,0,Qt.AlignHCenter); outer.addStretch()
        self.key.returnPressed.connect(self.do_activate); self.activator.returnPressed.connect(self.do_activate)
    def do_activate(self):
        from .license import activate
        ok,msg=activate(self.key.text(),self.activator.text())
        if ok: self.accept()
        else: self.error.setText(msg)

class SplashScreen(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent, Qt.SplashScreen | Qt.FramelessWindowHint)
        self.showFullScreen()
        self.setStyleSheet("QDialog{background:#2a1a0e;border:1px solid #6b4226;border-radius:20px} QLabel{color:#fff7ea}")
        lay=QVBoxLayout(self); lay.setContentsMargins(35,28,35,25); lay.setSpacing(12)
        logo=QLabel(); pix=QPixmap(str(ASSET_ROOT/"rubix_logo.png"))
        if not pix.isNull(): logo.setPixmap(pix.scaled(220,90,Qt.KeepAspectRatio,Qt.SmoothTransformation))
        logo.setAlignment(Qt.AlignCenter); lay.addWidget(logo)
        title=QLabel("RUBIX POS"); title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size:34px;font-weight:900;letter-spacing:3px;color:#ffffff"); lay.addWidget(title)
        subtitle=QLabel("SMART RETAIL • BILLING • INVENTORY")
        subtitle.setAlignment(Qt.AlignCenter); subtitle.setStyleSheet("font-size:13px;font-weight:700;color:#e0c097;letter-spacing:2px"); lay.addWidget(subtitle)
        lay.addStretch()
        line=QLabel("Preparing your billing workspace…"); line.setAlignment(Qt.AlignCenter)
        line.setStyleSheet("color:#e8d5b5;font-size:12px"); lay.addWidget(line)
        self.setWindowOpacity(0.0)
        self._opacity=0.0
        self._fade=QTimer(self); self._fade.timeout.connect(self._step); self._fade.start(25)
        QTimer.singleShot(1000,self.accept)
    def _step(self):
        self._opacity=min(1.0,self._opacity+0.12)
        self.setWindowOpacity(self._opacity)
        if self._opacity>=1: self._fade.stop()


class LoginDialog(QDialog):
    def __init__(self, db_path, parent=None):
        super().__init__(parent); self.db_path=Path(db_path); self.user=None; self.fails=0; self.locked_until=0
        self.setWindowTitle("RUBIX POS — Sign In"); self.showFullScreen()
        self.setStyleSheet("""QDialog{background:#f5efe6} QFrame#loginCard{background:#fffaf2;border:1px solid #d9c3a5;border-radius:14px}
          QLabel{color:#3b2414} QLineEdit{padding:12px 14px;border:1px solid #d6bf9f;border-radius:7px;background:#fffdf9;color:#3b2414;min-height:22px;font-size:14px}
          QLineEdit:focus{border:1px solid #8b5e3c;background:#ffffff} QPushButton{padding:12px;border:0;border-radius:7px;background:#6b4226;color:#fff7ea;font-weight:800;font-size:15px}
          QPushButton:hover{background:#8b5e3c}
        """)
        outer=QVBoxLayout(self); outer.setContentsMargins(20,20,20,20); outer.addStretch()
        row=QHBoxLayout(); row.setSpacing(44)
        brand=QVBoxLayout(); brand.setSpacing(8)
        brand_title=QLabel("RUBIX$"); brand_title.setStyleSheet("font-size:42px;font-weight:900;color:#6b4226"); brand.addWidget(brand_title)
        brand_desc=QLabel("Billing made simple.\nInventory under control."); brand_desc.setStyleSheet("font-size:20px;color:#7a5a3a"); brand.addWidget(brand_desc); brand.addStretch()
        brand_wrap=QWidget(); brand_wrap.setLayout(brand); brand_wrap.setFixedWidth(330); row.addWidget(brand_wrap,0,Qt.AlignVCenter)
        card=QFrame(); card.setObjectName("loginCard"); card.setFixedWidth(390)
        lay=QVBoxLayout(card); lay.setContentsMargins(26,28,26,25); lay.setSpacing(13)
        logo=QLabel(); pix=QPixmap(str(ASSET_ROOT/"rubix_logo.png"))
        if not pix.isNull(): logo.setPixmap(pix.scaled(125,52,Qt.KeepAspectRatio,Qt.SmoothTransformation))
        logo.setAlignment(Qt.AlignCenter); lay.addWidget(logo)
        t=QLabel("Log in to RUBIX POS"); t.setStyleSheet("font-size:21px;font-weight:800;color:#1c1e21"); t.setAlignment(Qt.AlignCenter); lay.addWidget(t)
        self.username=QLineEdit(); self.username.setPlaceholderText("Username"); self.username.setMinimumHeight(46)
        self.password=QLineEdit(); self.password.setPlaceholderText("Password"); self.password.setEchoMode(QLineEdit.Password); self.password.setMinimumHeight(46)
        lay.addWidget(self.username); lay.addWidget(self.password)
        self.error=QLabel(""); self.error.setWordWrap(True); self.error.setStyleSheet("color:#b42318;font-weight:600"); lay.addWidget(self.error)
        b=QPushButton("Log In"); b.setMinimumHeight(46); b.clicked.connect(self.authenticate); lay.addWidget(b)
        hint=QLabel("Use your assigned account credentials."); hint.setStyleSheet("color:#65676b;font-size:11px"); hint.setAlignment(Qt.AlignCenter); lay.addWidget(hint)
        row.addWidget(card,0,Qt.AlignVCenter); row.addStretch(); outer.addLayout(row); outer.addStretch()
        self.password.returnPressed.connect(self.authenticate); self.username.returnPressed.connect(lambda: self.password.setFocus())
    def authenticate(self):
        u=self.username.text().strip(); pw=self.password.text()
        if not u or not pw: self.error.setText("Enter both username and password."); return
        wait=int(getattr(self,"locked_until",0)-time.time())
        if wait>0: self.error.setText(f"Too many wrong attempts. Try again in {wait} seconds."); return
        c=connect(self.db_path); row=c.execute("SELECT id,name,username,role,active,password_hash FROM employees WHERE lower(username)=lower(?) LIMIT 1",(u,)).fetchone(); c.close()
        ok,upgrade=verify_password(pw,row["password_hash"]) if row else (False,False)
        if not row: verify_password(pw,"")  # keep timing similar for unknown users
        if row and row["active"] and ok:
            self.fails=0
            if upgrade or is_default_password(row["password_hash"]):
                c=connect(self.db_path)
                if upgrade: c.execute("UPDATE employees SET password_hash=? WHERE id=?",(hash_password(pw),row["id"])); c.commit()
                c.close()
            self.user=dict(row); self.user["must_change"]=(pw==DEFAULT_ADMIN_PASSWORD)
            self.user.pop("password_hash",None); self.accept(); return
        self.fails=getattr(self,"fails",0)+1
        if self.fails>=5:
            self.fails=0; self.locked_until=time.time()+60
            self.error.setText("Too many wrong attempts. Please wait 60 seconds."); return
        self.error.setText("Incorrect username or password. Please try again.")

class MainWindow(QMainWindow):
    def __init__(self, db_path):
        super().__init__()
        self.db_path=Path(db_path); self.backup_dir=self.db_path.parent.parent/"backups"
        self.cart=[]; self.held=[]; self.current_user="RUBIX"; self.current_role="Admin"; self.current_name="Admin"
        # Automatic local backup every 5 minutes while the POS is running.
        self.backup_timer=QTimer(self)
        self.backup_timer.setInterval(5 * 60 * 1000)
        self.backup_timer.timeout.connect(self.auto_backup)
        self.backup_timer.start()
        self.setWindowTitle("RUBIX$ — Point of Sale")
        sc=QShortcut(QKeySequence("F11"),self); sc.activated.connect(self.toggle_fullscreen)
        self.setMinimumSize(1180,760)
        QApplication.instance().setStyleSheet(THEME_CSS)
        QApplication.instance().setFont(QFont("Segoe UI", 10))
        # UI is built after successful sign-in so the window is role-aware.

    def update_system_clock(self):
        if hasattr(self, "clock_label"):
            self.clock_label.setText(datetime.now().astimezone().strftime("%d-%m-%Y  %I:%M:%S %p"))

    def db(self): return connect(self.db_path)
    def btn(self,text,fn): b=QPushButton(text); b.clicked.connect(fn); return b
    def log(self,action,details=""):
        c=self.db(); c.execute("INSERT INTO audit_logs(username,action,details,created_at) VALUES(?,?,?,?)",(self.current_user,action,details,datetime.now().isoformat(timespec="seconds"))); c.commit(); c.close()

    def build_ui(self):
        self.session_no="SES-"+datetime.now().strftime("%Y%m%d-%H%M%S")  # one login session = one shift
        root=QWidget(); root.setObjectName("page"); self.setCentralWidget(root)
        lay=QVBoxLayout(root); lay.setContentsMargins(12,12,12,12); lay.setSpacing(7)
        header=QFrame(); header.setObjectName("header"); header.setMinimumHeight(70); header.setMaximumHeight(78)
        h=QHBoxLayout(header); h.setContentsMargins(18,10,18,10); h.setSpacing(12)
        logo=QLabel(); logo.setPixmap(QPixmap(str(ASSET_ROOT/"rubix_logo.png")).scaled(155,58,Qt.KeepAspectRatio,Qt.SmoothTransformation)); h.addWidget(logo)
        title=QLabel("RUBIX$"); title.setObjectName("heroTitle"); h.addWidget(title)
        h.addStretch()
        self.clock_label=QLabel(); self.clock_label.setStyleSheet("color:#ffffff;font-size:14px;font-weight:800;padding:6px 10px;border:1px solid #d9b98f;border-radius:7px")
        h.addWidget(self.clock_label)
        self.clock_timer=QTimer(self); self.clock_timer.timeout.connect(self.update_system_clock); self.clock_timer.start(1000); self.update_system_clock()
        try:
            from .license import machine_id
            device_badge=QLabel("SYSTEM ID  "+machine_id()[:12]); device_badge.setStyleSheet("color:#f3e3c9;font-size:10px;font-weight:700;padding:5px 8px;border:1px solid #d9b98f;border-radius:6px"); h.addWidget(device_badge)
        except Exception: pass
        # Professional user/profile icon (clean outline style instead of the cartoon avatar)
        avatar=QLabel(); avatar.setPixmap(QPixmap(str(ASSET_ROOT/"user_profile.svg")).scaled(44,44,Qt.KeepAspectRatio,Qt.SmoothTransformation)); avatar.setToolTip("Signed-in user"); h.addWidget(avatar)
        self.user_label=QLabel(f"{self.current_name}\n{self.current_role}"); self.user_label.setStyleSheet("color:#fff7ea;font-weight:800"); h.addWidget(self.user_label)
        self.refresh_btn=QToolButton(); self.refresh_btn.setText("↻"); self.refresh_btn.setObjectName("refreshButton"); self.refresh_btn.setToolTip("Refresh all data"); self.refresh_btn.setCursor(Qt.PointingHandCursor); self.refresh_btn.clicked.connect(self.refresh_all); h.addWidget(self.refresh_btn)
        self.more_btn=QToolButton(); self.more_btn.setText("More ▾"); self.more_btn.setObjectName("moreButton"); self.more_btn.setMinimumWidth(76); self.more_btn.setMaximumWidth(92); self.more_btn.setMinimumHeight(30); self.more_btn.setPopupMode(QToolButton.InstantPopup); self.more_btn.setToolButtonStyle(Qt.ToolButtonTextOnly); h.addWidget(self.more_btn)
        self.signout_btn=QPushButton("Sign Out"); self.signout_btn.setObjectName("signoutButton"); h.addWidget(self.signout_btn)
        lay.addWidget(header)
        self.tabs=QTabWidget(); self.tabs.setDocumentMode(True); self.tabs.setUsesScrollButtons(False); self.tabs.setStyleSheet("QTabBar::tab{padding:7px 10px;margin:2px;border-radius:7px;font-size:11px} QTabWidget::pane{top:-1px}"); lay.addWidget(self.tabs,1)
        self.build_billing(); self.build_products(); self.build_customers(); self.build_suppliers(); self.build_purchases(); self.build_expenses(); self.build_reports(); self.build_employees(); self.build_data_reports()
        icon_names=["billing","products","customers","products","products","reports","reports","customers","reports","reports","reports"]
        for idx,name in enumerate(icon_names):
            if idx < self.tabs.count(): self.tabs.setTabIcon(idx,QIcon(str(ASSET_ROOT/"icons"/f"{name}.svg")))
        # Keep the primary workspace clean; secondary tools live under More.
        # Only the three core workspaces stay visible. Everything else is grouped cleanly under More.
        self.primary_tabs={0}; self.secondary_tabs=set(range(self.tabs.count()))-self.primary_tabs
        for idx in range(self.tabs.count()): self.tabs.setTabVisible(idx, idx in self.primary_tabs)
        self.tabs.currentChanged.connect(self._tab_changed)
        menu=QMenu(self); menu.setMinimumWidth(270)
        actions=[("📦  Products / Inventory",1), ("👥  CRM / Customers",2), ("🗂  Data — Sales Report & Download",8), ("📦  Stock Report",9), ("👥  Customer Report",10), ("📊  Dashboard / AI Analytics",6), ("🚚  Suppliers",3), ("📦  Purchases / Stock-In",4), ("💰  Expenses / Finance",5)]
        for label,idx in actions:
            a=menu.addAction(label); a.triggered.connect(lambda checked=False,i=idx:self.open_secondary(i))
        menu.addSeparator()
        if self.current_role == "Admin":
            a=menu.addAction("👥  Users & Access"); a.triggered.connect(lambda:self.open_secondary(7))
        a=menu.addAction("🔑  Change My Password"); a.triggered.connect(self.change_my_password)
        if self.current_role in ("Admin","Manager"):
            a=menu.addAction("🏪  Store Details (bill header)"); a.triggered.connect(self.shop_setup)
        a=menu.addAction("🖨  Printer Setup"); a.triggered.connect(self.printer_setup)
        a=menu.addAction("🔫  Scanner Setup"); a.triggered.connect(self.scanner_setup)
        menu.addSeparator()
        a=menu.addAction("⛶  Full Screen  (F11)"); a.triggered.connect(self.toggle_fullscreen)
        a=menu.addAction("⏻  Exit Application"); a.triggered.connect(self.close)
        self.more_btn.setMenu(menu)
        self.signout_btn.clicked.connect(self.sign_out)

    def toggle_fullscreen(self):
        if self.isFullScreen(): self.showMaximized()
        else: self.showFullScreen()

    def get_meta(self,key,default=""):
        c=self.db(); r=c.execute("SELECT value FROM app_meta WHERE key=?",(key,)).fetchone(); c.close()
        return r["value"] if r else default
    def set_meta(self,key,value):
        c=self.db(); c.execute("INSERT OR REPLACE INTO app_meta(key,value) VALUES(?,?)",(key,str(value))); c.commit(); c.close()

    def _tab_changed(self,index):
        if index==0 and hasattr(self,"scan"): self.scan.setFocus()
        if not hasattr(self,"primary_tabs"): return
        for i in range(self.tabs.count()): self.tabs.setTabVisible(i, i in self.primary_tabs or i==index)
    def open_secondary(self,index):
        if index >= self.tabs.count(): return
        self.tabs.setTabVisible(index, True); self.tabs.setCurrentIndex(index)

    def build_billing(self):
        tab=QWidget(); main=QHBoxLayout(tab); left=QVBoxLayout(); right=QVBoxLayout()
        search=QHBoxLayout(); self.scan=QLineEdit(); self.scan.setPlaceholderText("🔎 Scan barcode / search product..."); self.scan.returnPressed.connect(self.add_scan_item); search.addWidget(self.scan,1); search.addWidget(self.btn("ADD",self.add_scan_item)); search.addWidget(self.btn("HOLD BILL",self.hold_bill)); search.addWidget(self.btn("RESUME",self.resume_bill)); left.addLayout(search)
        self.scanner_auto=self.get_meta("scanner_auto","1")=="1"
        try: self.scanner_minlen=max(3,int(self.get_meta("scanner_minlen","6")))
        except ValueError: self.scanner_minlen=6
        self._scan_last=0.0; self._scan_fast=0
        self._scan_timer=QTimer(self); self._scan_timer.setSingleShot(True); self._scan_timer.timeout.connect(self.add_scan_item)
        self.scan.textChanged.connect(self._maybe_auto_scan)
        self.cart_table=QTableWidget(0,7); self.cart_table.setHorizontalHeaderLabels(["Barcode","Product","Qty","Price","Tax","Total","Adjust"]); self.cart_table.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch); self.cart_table.setMinimumHeight(330); self.cart_table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded); left.addWidget(self.cart_table,1)
        qrow=QHBoxLayout(); qrow.setSpacing(8); qrow.addWidget(QLabel("Qty to add:"));
        self.qty=QSpinBox(); self.qty.setRange(1,9999); self.qty.setValue(1); self.qty.setButtonSymbols(QAbstractSpinBox.NoButtons); self.qty.setMinimumWidth(58); self.qty.setMaximumWidth(70); self.qty.setAlignment(Qt.AlignCenter)
        qminus=self.btn("−",lambda:self.change_scan_qty(-1)); qminus.setObjectName("qtyMinus"); qminus.setFixedSize(28,28)
        qplus=self.btn("+",lambda:self.change_scan_qty(1)); qplus.setObjectName("qtyPlus"); qplus.setFixedSize(28,28)
        qrow.addWidget(qminus); qrow.addWidget(self.qty); qrow.addWidget(qplus); qrow.addWidget(self.btn("Clear Bill",self.clear_cart)); qrow.addStretch(); left.addLayout(qrow)
        cust=QFormLayout(); self.customer=QLineEdit(); self.customer.setPlaceholderText("Enter customer phone number"); self.payment=QComboBox(); self.payment.addItems(["Cash","UPI","Card","Wallet","Split"]); self.discount=QDoubleSpinBox(); self.discount.setRange(0,1e9); self.discount.setPrefix("₹ "); self.discount.valueChanged.connect(self.update_totals)
        self.disc_type=QComboBox(); self.disc_type.addItems(["₹","%"]); self.disc_type.setFixedWidth(54); self.disc_type.currentIndexChanged.connect(self._disc_type_changed)
        drow=QWidget(); dl=QHBoxLayout(drow); dl.setContentsMargins(0,0,0,0); dl.addWidget(self.discount,1); dl.addWidget(self.disc_type)
        self.cust_info=QLabel(""); self.cust_info.setStyleSheet("color:#6b4226;font-weight:700"); self.customer.textChanged.connect(self._customer_lookup)
        cust.addRow("Customer Phone:",self.customer); cust.addRow("",self.cust_info); cust.addRow("Payment:",self.payment); cust.addRow("Discount:",drow); left.addLayout(cust)
        for key,fn in [("F2",self.checkout),("F3",lambda:self.scan.setFocus()),("F4",self.hold_bill),("F6",self.resume_bill),("F8",self.clear_cart)]:
            sc=QShortcut(QKeySequence(key),self); sc.activated.connect(fn)
        right.addWidget(QLabel("🧾 BILL SUMMARY"),alignment=Qt.AlignCenter); self.summary=QLabel(); self.summary.setFont(QFont("Segoe UI",14,QFont.Bold)); right.addWidget(self.summary); right.addStretch(); right.addWidget(self.btn("💳 CHECKOUT / PRINT",self.checkout)); right.addWidget(self.btn("↩ RETURN / REFUND",self.return_sale)); right.addWidget(self.btn("📄 EXPORT LAST INVOICE",self.export_invoice)); right.addWidget(self.btn("🖨 PRINT LAST BILL",self.reprint_last)); right.addWidget(self.btn("🖨 PRINTER SETUP",self.printer_setup)); right.addWidget(self.btn("🔫 SCANNER SETUP",self.scanner_setup)); main.addLayout(left,3); main.addLayout(right,1); self.tabs.addTab(tab,"🧾 POS Billing")

    def build_products(self):
        tab=QWidget(); outer=QVBoxLayout(tab); outer.setContentsMargins(0,0,0,0)
        scroll=QScrollArea(); scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame); outer.addWidget(scroll)
        scroll.viewport().setStyleSheet("background:#ffffff"); page=QWidget(); page.setObjectName("invPage"); scroll.setWidget(page)
        l=QVBoxLayout(page); l.setContentsMargins(20,16,20,16); l.setSpacing(14)
        self.pb=QLineEdit(); self.pn=QLineEdit(); self.pc=QLineEdit(); self.pp=QDoubleSpinBox(); self.ps=QDoubleSpinBox(); self.pst=QDoubleSpinBox(); self.pmin=QDoubleSpinBox(); self.ptax=QDoubleSpinBox(); self.pu=QLineEdit("pcs"); self.pe=QLineEdit()
        field_css="min-height:0px;max-height:40px;padding:0px 12px;border:1px solid #d6bf9f;border-radius:9px;background:#fffdf9;color:#3b2414"
        for x in [self.pp,self.ps,self.pst,self.pmin,self.ptax]:
            x.setRange(0,1e9); x.setDecimals(2); x.setButtonSymbols(QAbstractSpinBox.NoButtons); x.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
        self.ptax.setRange(0,100); self.ptax.setSuffix(" %")
        self.pb.setPlaceholderText("Scan or type barcode"); self.pn.setPlaceholderText("Product name"); self.pc.setPlaceholderText("Category"); self.pe.setPlaceholderText("YYYY-MM-DD (optional)")
        # Every field is its own separate box: label on top, 40px input underneath, 4 columns x 2 rows.
        grid=QGridLayout(); grid.setHorizontalSpacing(16); grid.setVerticalSpacing(12)
        fields=[("Barcode",self.pb),("Name",self.pn),("Category",self.pc),("Purchase Price",self.pp),("Selling Price",self.ps),("Stock",self.pst),("Minimum Stock",self.pmin),("GST/Tax %",self.ptax),("Unit",self.pu),("Expiry Date",self.pe)]
        for i,(lab,w) in enumerate(fields):
            box=QWidget(); v=QVBoxLayout(box); v.setContentsMargins(0,0,0,0); v.setSpacing(4)
            lb=QLabel(lab); lb.setStyleSheet("font-weight:700;color:#4a2f1b;font-size:12px")
            w.setFixedHeight(40); w.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            w.setStyleSheet(("QLineEdit" if isinstance(w,QLineEdit) else "QDoubleSpinBox")+"{"+field_css+"}")
            if isinstance(w,QDoubleSpinBox): w.lineEdit().setStyleSheet("border:0;background:transparent;padding:0;min-height:0px;color:#3b2414")
            v.addWidget(lb); v.addWidget(w)
            grid.addWidget(box,i//4,i%4)
        for c in range(4): grid.setColumnStretch(c,1)
        l.addLayout(grid)
        self.product_search=QLineEdit(); self.product_search.setPlaceholderText("Search inventory by product, barcode or category…")
        self.product_search.textChanged.connect(self.filter_products); l.addWidget(self.product_search)
        r=QHBoxLayout()
        for txt,fn in [("SAVE PRODUCT",self.save_product),("NEW / CLEAR",self.clear_product_form),("BARCODE PDF",self.make_barcode),("DELETE SELECTED",self.delete_product),("IMPORT CSV",self.import_products)]: r.addWidget(self.btn(txt,fn))
        l.addLayout(r); self.products_table=QTableWidget(0,11); self.products_table.setHorizontalHeaderLabels(["ID","Barcode","Name","Category","Buy","Sell","Stock","Min","Tax%","Unit","Expiry"]); self.products_table.setAlternatingRowColors(True); self.products_table.setWordWrap(False); self.products_table.setMinimumHeight(260); self.products_table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded); self.products_table.horizontalHeader().setSectionResizeMode(2,QHeaderView.Stretch); self._prep_table(self.products_table); self.products_table.itemSelectionChanged.connect(self.product_selected); l.addWidget(self.products_table,1); self.tabs.addTab(tab,"📦 Products & Inventory")

    def build_customers(self):
        tab=QWidget(); l=QVBoxLayout(tab); f=QFormLayout(); self.cn=QLineEdit(); self.cp=QLineEdit(); self.ce=QLineEdit(); self.ca=QLineEdit()
        for lab,w in [("Name",self.cn),("Phone",self.cp),("Email",self.ce),("Address",self.ca)]: f.addRow(lab,w)
        l.addLayout(f); rb=QHBoxLayout(); [rb.addWidget(self.btn(t,fn)) for t,fn in [("SAVE CUSTOMER",self.save_customer),("NEW / CLEAR",self.clear_customer_form),("DELETE SELECTED",self.delete_customer),("IMPORT CSV",self.import_customers)]]; l.addLayout(rb)
        self.customer_search=QLineEdit(); self.customer_search.setPlaceholderText("Search CRM by name, phone, email or membership…")
        self.customer_search.textChanged.connect(self.filter_customers); l.addWidget(self.customer_search)
        self.ct=QTableWidget(0,7); self.ct.setHorizontalHeaderLabels(["ID","Name","Phone","Email","Membership","Points","Credit"]); self._prep_table(self.ct); self.ct.itemSelectionChanged.connect(self.customer_selected); l.addWidget(self.ct); self.tabs.addTab(tab,"👥 CRM / Customers")

    def build_suppliers(self):
        tab=QWidget(); l=QVBoxLayout(tab); f=QFormLayout(); self.sn=QLineEdit(); self.sp=QLineEdit(); self.se=QLineEdit(); self.sa=QLineEdit()
        for lab,w in [("Supplier",self.sn),("Phone",self.sp),("Email",self.se),("Address",self.sa)]: f.addRow(lab,w)
        l.addLayout(f); rb=QHBoxLayout(); [rb.addWidget(self.btn(t,fn)) for t,fn in [("SAVE SUPPLIER",self.save_supplier),("NEW / CLEAR",self.clear_supplier_form),("DELETE SELECTED",self.delete_supplier),("PAY BALANCE",self.pay_supplier_balance)]]; l.addLayout(rb); self.st=QTableWidget(0,6); self.st.setHorizontalHeaderLabels(["ID","Supplier","Phone","Email","Address","Balance"]); self._prep_table(self.st); self.st.itemSelectionChanged.connect(self.supplier_selected); l.addWidget(self.st); self.tabs.addTab(tab,"🚚 Suppliers")

    def build_purchases(self):
        tab=QWidget(); l=QVBoxLayout(tab); l.addWidget(QLabel("Purchase / Stock-In Manager"))
        form=QHBoxLayout(); self.purchase_product=QLineEdit(); self.purchase_product.setPlaceholderText("Barcode or product name / scanner input")
        self.purchase_qty=QDoubleSpinBox(); self.purchase_qty.setRange(1,1e9); self.purchase_qty.setValue(1); self.purchase_qty.setButtonSymbols(QAbstractSpinBox.NoButtons); self.purchase_qty.setAlignment(Qt.AlignCenter); self.purchase_qty.setMinimumWidth(92)
        pminus=self.btn("−",lambda:self.change_purchase_qty(-1)); pminus.setObjectName("qtyMinus"); pminus.setFixedSize(38,36)
        pplus=self.btn("+",lambda:self.change_purchase_qty(1)); pplus.setObjectName("qtyPlus"); pplus.setFixedSize(38,36)
        self.purchase_cost=QDoubleSpinBox(); self.purchase_cost.setRange(0,1e9); self.purchase_cost.setPrefix("₹ ")
        self.purchase_supplier=QComboBox(); self.purchase_supplier.addItem("— No supplier —",None); self.purchase_pay=QComboBox(); self.purchase_pay.addItems(["Cash","UPI","Bank","Credit"]); self.purchase_pay.setToolTip("Credit = pay the supplier later (added to supplier balance)")
        form.addWidget(self.purchase_product,1); form.addWidget(pminus); form.addWidget(self.purchase_qty); form.addWidget(pplus); form.addWidget(self.purchase_cost); form.addWidget(self.purchase_supplier); form.addWidget(self.purchase_pay); form.addWidget(self.btn("STOCK IN",self.stock_in)); l.addLayout(form)
        self.pt=QTableWidget(0,7); self.pt.setHorizontalHeaderLabels(["ID","Product","Barcode","Stock","Buy Price","Sell Price","Expiry"]); l.addWidget(self.pt); self.tabs.addTab(tab,"🚚 Purchases / Stock-In")

    def build_expenses(self):
        tab=QWidget(); l=QVBoxLayout(tab); f=QFormLayout(); self.ec=QLineEdit(); self.ed=QLineEdit(); self.ea=QDoubleSpinBox(); self.ea.setRange(0,1e9); self.ep=QComboBox(); self.ep.addItems(["Cash","UPI","Card","Bank"])
        f.addRow("Category",self.ec); f.addRow("Description",self.ed); f.addRow("Amount",self.ea); f.addRow("Payment",self.ep); l.addLayout(f); rb=QHBoxLayout(); [rb.addWidget(self.btn(t,fn)) for t,fn in [("SAVE EXPENSE",self.save_expense),("NEW / CLEAR",self.clear_expense_form),("DELETE SELECTED",self.delete_expense)]]; l.addLayout(rb); self.et=QTableWidget(0,5); self.et.setHorizontalHeaderLabels(["ID","Category","Description","Amount","Date"]); self._prep_table(self.et); self.et.itemSelectionChanged.connect(self.expense_selected); l.addWidget(self.et); self.tabs.addTab(tab,"💰 Expenses / Finance")

    def build_reports(self):
        tab=QWidget(); l=QVBoxLayout(tab); cards=QGridLayout()
        self.kpis={}
        for i,(key,label) in enumerate([("sales","Today's Sales"),("bills","Bills"),("profit","Est. Profit"),("low","Low Stock"),("cust","Customers"),("prod","Products")]):
            box=QGroupBox(label); bl=QVBoxLayout(box); self.kpis[key]=QLabel("0"); self.kpis[key].setFont(QFont("Segoe UI",18,QFont.Bold)); bl.addWidget(self.kpis[key]); cards.addWidget(box,0,i)
        l.addLayout(cards); self.ai=QTextEdit(); self.ai.setReadOnly(True); l.addWidget(self.ai); row=QHBoxLayout(); row.addWidget(self.btn("🤖 RUN AI BUSINESS INSIGHTS",self.ai_insights)); row.addWidget(self.btn("📊 EXPORT SALES CSV",self.export_csv)); l.addLayout(row)
        self.rt=QTableWidget(0,6); self.rt.setHorizontalHeaderLabels(["Invoice","Customer","Subtotal","Discount","Tax","Total"]); l.addWidget(self.rt); self.tabs.addTab(tab,"📊 Dashboard / AI Analytics")

    def build_employees(self):
        tab=QWidget(); l=QVBoxLayout(tab); f=QFormLayout(); self.en=QLineEdit(); self.eu=QLineEdit(); self.er=QComboBox(); self.er.addItems(["Admin","Manager","Cashier","Accountant"]); self.eph=QLineEdit(); self.epw=QLineEdit(); self.epw.setPlaceholderText("Set initial password"); self.epw.setEchoMode(QLineEdit.Password)
        for lab,w in [("Name",self.en),("Username",self.eu),("Password",self.epw),("Role",self.er),("Phone",self.eph)]: f.addRow(lab,w)
        l.addLayout(f); row=QHBoxLayout(); row.addWidget(self.btn("ADD USER",self.save_employee)); row.addWidget(self.btn("UPDATE USER",self.update_user)); row.addWidget(self.btn("DELETE USER",self.delete_user)); row.addWidget(self.btn("NEW / CLEAR",self.clear_user_form)); row.addWidget(self.btn("RESET USERNAME",self.reset_username)); row.addWidget(self.btn("RESET PASSWORD",self.reset_user_password)); row.addWidget(self.btn("ENABLE / DISABLE",self.toggle_user)); row.addStretch(); l.addLayout(row)
        self.emt=QTableWidget(0,6); self.emt.setHorizontalHeaderLabels(["ID","Name","Username","Role","Phone","Status"]); self.emt.setMinimumHeight(360); self._prep_table(self.emt); self.emt.itemSelectionChanged.connect(self.user_selected); l.addWidget(self.emt,1); self.tabs.addTab(tab,"Users & Access")

    def build_data_reports(self):
        # DATA tab: date-wise / monthly / yearly sales with a CSV download at the bottom.
        self.sales_report_tab=QWidget(); sl=QVBoxLayout(self.sales_report_tab); sl.setContentsMargins(18,14,18,14); sl.setSpacing(10)
        title=QLabel("🗂  DATA — SALES REPORT"); title.setStyleSheet("font-size:16px;font-weight:800;color:#4a2f1b"); sl.addWidget(title)
        top=QHBoxLayout(); top.setSpacing(10)
        self.rep_period=QComboBox(); self.rep_period.addItems(["Daily","Monthly","Yearly"])
        self.rep_date=QDateEdit(QDate.currentDate()); self.rep_date.setCalendarPopup(True); self.rep_date.setDisplayFormat("dd-MM-yyyy")
        top.addWidget(QLabel("View:")); top.addWidget(self.rep_period); top.addWidget(QLabel("Date:")); top.addWidget(self.rep_date)
        top.addWidget(self.btn("TODAY SALES",self.rep_today)); top.addWidget(self.btn("REFRESH",self.refresh_sales_data)); top.addStretch(); sl.addLayout(top)
        cards=QHBoxLayout(); self.rep_cards={}
        for key,label in [("bills","BILLS"),("qty","ITEMS SOLD"),("sales","TOTAL SALES"),("gst","GST"),("profit","PROFIT")]:
            f=QFrame(); f.setObjectName("statCard"); v=QVBoxLayout(f); v.setContentsMargins(14,8,14,8); v.setSpacing(0)
            n=QLabel(label); n.setObjectName("statName"); val=QLabel("0"); val.setObjectName("statValue"); v.addWidget(n); v.addWidget(val); cards.addWidget(f); self.rep_cards[key]=val
        sl.addLayout(cards)
        self.sales_report_table=QTableWidget(0,0); self.sales_report_table.setAlternatingRowColors(True); self.sales_report_table.setEditTriggers(QAbstractItemView.NoEditTriggers); self.sales_report_table.setSelectionBehavior(QAbstractItemView.SelectRows); sl.addWidget(self.sales_report_table,1)
        bottom=QHBoxLayout(); bottom.setSpacing(10)
        self.rep_details=QCheckBox("Monthly / Yearly: also save the bill-wise detail file"); self.rep_details.setChecked(True); bottom.addWidget(self.rep_details); bottom.addStretch()
        if self.current_role in ("Admin","Accountant"): bottom.addWidget(self.btn("🗂 EXPORT ALL DATA",self.data_center))
        bottom.addWidget(self.btn("⬇  DOWNLOAD CSV  (Daily / Monthly / Yearly)",self.download_sales_csv)); sl.addLayout(bottom)
        self.rep_period.currentIndexChanged.connect(self._rep_period_changed); self.rep_date.dateChanged.connect(lambda *_: self.refresh_sales_data())
        self._rep_period_changed()
        self.tabs.addTab(self.sales_report_tab,"Data / Sales Report")
        self.stock_report_tab=QWidget(); il=QVBoxLayout(self.stock_report_tab)
        il.addWidget(QLabel("STOCK REPORT — current inventory and reorder status"))
        self.stock_report_table=QTableWidget(0,7); self.stock_report_table.setHorizontalHeaderLabels(["Barcode","Product","Category","Stock","Minimum","Status","Selling Price"]); self.stock_report_table.horizontalHeader().setSectionResizeMode(1,QHeaderView.Stretch); il.addWidget(self.stock_report_table,1)
        il.addWidget(self.btn("REFRESH STOCK REPORT",self.refresh_data_reports)); self.tabs.addTab(self.stock_report_tab,"Stock Report")
        self.customer_report_tab=QWidget(); cl=QVBoxLayout(self.customer_report_tab)
        cl.addWidget(QLabel("CUSTOMER REPORT — customer directory and purchase totals"))
        self.customer_report_table=QTableWidget(0,6); self.customer_report_table.setHorizontalHeaderLabels(["Name","Phone","Email","Bills","Total Spend","Last Purchase"]); self.customer_report_table.horizontalHeader().setSectionResizeMode(0,QHeaderView.Stretch); cl.addWidget(self.customer_report_table,1)
        cl.addWidget(self.btn("REFRESH CUSTOMER REPORT",self.refresh_data_reports)); self.tabs.addTab(self.customer_report_tab,"Customer Report")

    # ----- sales data helpers (shared by the on-screen table and the CSV download) -----
    def _rep_period_changed(self,*_):
        p=self.rep_period.currentText()
        self.rep_date.setDisplayFormat({"Daily":"dd-MM-yyyy","Monthly":"MMMM yyyy","Yearly":"yyyy"}.get(p,"dd-MM-yyyy"))
        self.refresh_sales_data()
    def rep_today(self):
        self.rep_period.setCurrentText("Daily"); self.rep_date.setDate(QDate.currentDate()); self.refresh_sales_data()
    def _rep_range(self):
        d=self.rep_date.date(); p=self.rep_period.currentText()
        if p=="Daily": st=en=d
        elif p=="Monthly": st=QDate(d.year(),d.month(),1); en=st.addMonths(1).addDays(-1)
        else: st=QDate(d.year(),1,1); en=QDate(d.year(),12,31)
        return p,st.toString("yyyy-MM-dd"),en.toString("yyyy-MM-dd")
    def _fetch_sales_lines(self,start,end):
        c=self.db()
        rows=c.execute("""SELECT s.session_no,s.invoice_no,s.created_at,COALESCE(cu.name,'Walk-in') AS customer,p.name AS product,si.quantity,si.price,si.tax_rate,si.line_total,
            COALESCE(NULLIF(si.cost,0),p.purchase_price,0) AS cost,s.subtotal,s.discount,s.total,s.payment_method,s.status
            FROM sale_items si JOIN sales s ON s.id=si.sale_id JOIN products p ON p.id=si.product_id LEFT JOIN customers cu ON cu.id=s.customer_id
            WHERE date(s.created_at) BETWEEN ? AND ? ORDER BY s.created_at,s.id,si.id""",(start,end)).fetchall(); c.close()
        lines=[]
        for r in rows:
            qty=float(r["quantity"]); price=float(r["price"]); lt=float(r["line_total"]); gst=lt*float(r["tax_rate"] or 0)/100
            sub=float(r["subtotal"] or 0); share=(float(r["discount"] or 0)*lt/sub) if sub else 0.0
            try: dt=datetime.fromisoformat(str(r["created_at"]))
            except ValueError: dt=None
            lines.append(dict(session=r["session_no"] or "-",bill=r["invoice_no"],when=(dt.strftime("%d-%m-%Y %H:%M:%S") if dt else str(r["created_at"])),day=(dt.strftime("%Y-%m-%d") if dt else str(r["created_at"])[:10]),
                customer=r["customer"],product=r["product"],qty=qty,price=price,sub=price*qty,gst=gst,total=lt+gst,profit=qty*(price-float(r["cost"]))-share,disc=share,
                bill_total=float(r["total"]),payment=r["payment_method"],status=r["status"] or "COMPLETED"))
        return lines
    def _sales_totals(self,lines):
        t=dict(bills=0,qty=0.0,sales=0.0,gst=0.0,profit=0.0,sub=0.0,disc=0.0,total=0.0); seen=set()
        for l in lines:
            if l["status"]!="COMPLETED": continue
            t["qty"]+=l["qty"]; t["gst"]+=l["gst"]; t["profit"]+=l["profit"]; t["sub"]+=l["sub"]; t["disc"]+=l["disc"]; t["total"]+=l["total"]
            if l["bill"] not in seen: seen.add(l["bill"]); t["sales"]+=l["bill_total"]
        t["bills"]=len(seen); return t
    def _detail_table(self,lines):
        header=["Session","Bill No","Date Time","Customer","Product","Qty","Price","GST","Total","Profit","Bill Total","Payment Type","Status"]
        rows=[[l["session"],l["bill"],l["when"],l["customer"],l["product"],f"{l['qty']:g}",f"{l['price']:.2f}",f"{l['gst']:.2f}",f"{l['total']:.2f}",f"{l['profit']:.2f}",f"{l['bill_total']:.2f}",l["payment"],l["status"]] for l in lines]
        t=self._sales_totals(lines)
        rows.append(["TOTAL","",f"{t['bills']} bills","","",f"{t['qty']:g}","",f"{t['gst']:.2f}",f"{t['total']:.2f}",f"{t['profit']:.2f}",f"{t['sales']:.2f}","",""])
        return header,rows
    def _summary_table(self,lines,period):
        monthly=(period=="Monthly"); groups={}; seen=set()
        for l in lines:
            if l["status"]!="COMPLETED": continue
            key=l["day"] if monthly else l["day"][:7]
            g=groups.setdefault(key,dict(bills=set(),qty=0.0,sub=0.0,disc=0.0,gst=0.0,total=0.0,profit=0.0))
            g["bills"].add(l["bill"]); g["qty"]+=l["qty"]; g["sub"]+=l["sub"]; g["disc"]+=l["disc"]; g["gst"]+=l["gst"]; g["profit"]+=l["profit"]
            if l["bill"] not in seen: seen.add(l["bill"]); g["total"]+=l["bill_total"]
        header=["Date" if monthly else "Month","Bills","Items Sold","Sub Total","Discount","GST","Total Sales","Profit"]; rows=[]
        for key in sorted(groups):
            g=groups[key]
            try: label=datetime.strptime(key,"%Y-%m-%d").strftime("%d-%m-%Y (%a)") if monthly else datetime.strptime(key,"%Y-%m").strftime("%B %Y")
            except ValueError: label=key
            rows.append([label,str(len(g["bills"])),f"{g['qty']:g}",f"{g['sub']:.2f}",f"{g['disc']:.2f}",f"{g['gst']:.2f}",f"{g['total']:.2f}",f"{g['profit']:.2f}"])
        t=self._sales_totals(lines)
        rows.append(["TOTAL",str(t["bills"]),f"{t['qty']:g}",f"{t['sub']:.2f}",f"{t['disc']:.2f}",f"{t['gst']:.2f}",f"{t['sales']:.2f}",f"{t['profit']:.2f}"])
        return header,rows
    def refresh_sales_data(self,*_):
        if not hasattr(self,"sales_report_table"): return
        period,start,end=self._rep_range(); lines=self._fetch_sales_lines(start,end)
        header,rows=self._detail_table(lines) if period=="Daily" else self._summary_table(lines,period)
        tbl=self.sales_report_table; tbl.clear(); tbl.setColumnCount(len(header)); tbl.setRowCount(len(rows)); tbl.setHorizontalHeaderLabels(header)
        numeric=set(range(1,len(header))) if period!="Daily" else {5,6,7,8,9,10}
        for r,row in enumerate(rows):
            last=(r==len(rows)-1)
            for j,v in enumerate(row):
                it=QTableWidgetItem(str(v))
                if j in numeric: it.setTextAlignment(Qt.AlignRight|Qt.AlignVCenter)
                if last: f=it.font(); f.setBold(True); it.setFont(f)
                tbl.setItem(r,j,it)
        tbl.resizeColumnsToContents(); tbl.horizontalHeader().setStretchLastSection(True)
        t=self._sales_totals(lines)
        for k,v in [("bills",str(t["bills"])),("qty",f"{t['qty']:g}"),("sales",f"₹{t['sales']:.2f}"),("gst",f"₹{t['gst']:.2f}"),("profit",f"₹{t['profit']:.2f}")]: self.rep_cards[k].setText(v)
    def _write_csv(self,path,header,rows):
        with open(path,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f); w.writerow(header); w.writerows(rows)
    def download_sales_csv(self):
        period,start,end=self._rep_range(); lines=self._fetch_sales_lines(start,end)
        if not lines: return QMessageBox.information(self,"Download","No sales found for the selected period.")
        tag={"Daily":start,"Monthly":start[:7],"Yearly":start[:4]}[period]
        exp=self.db_path.parent/"exports"; exp.mkdir(parents=True,exist_ok=True)
        path,_=QFileDialog.getSaveFileName(self,"Save sales report",str(exp/f"sales_{period.lower()}_{tag}.csv"),"CSV files (*.csv)")
        if not path: return
        if not path.lower().endswith(".csv"): path+=".csv"
        try:
            saved=[path]
            if period=="Daily":
                h,r=self._detail_table(lines); self._write_csv(path,h,r)
            else:
                h,r=self._summary_table(lines,period); self._write_csv(path,h,r)
                if self.rep_details.isChecked():
                    dpath=path[:-4]+"_bill_details.csv"; dh,dr=self._detail_table(lines); self._write_csv(dpath,dh,dr); saved.append(dpath)
            self.log("SALES_CSV",f"{period} {tag}; files={len(saved)}")
            QMessageBox.information(self,"Download complete","Saved:\n"+"\n".join(saved))
        except OSError as e:
            QMessageBox.critical(self,"Download failed",f"Could not save the file:\n{e}")

    def refresh_data_reports(self):
        self.refresh_sales_data()
        c=self.db()
        stocks=c.execute("SELECT barcode,name,category,stock,min_stock,CASE WHEN stock<=min_stock THEN 'LOW STOCK' ELSE 'OK' END,selling_price FROM products WHERE active=1 ORDER BY name COLLATE NOCASE").fetchall()
        self.stock_report_table.setRowCount(len(stocks))
        for r,row in enumerate(stocks):
            for j,v in enumerate(row): self.stock_report_table.setItem(r,j,QTableWidgetItem(str(v if v is not None else '')))
        customers=c.execute("SELECT cu.name,cu.phone,cu.email,COUNT(s.id),COALESCE(SUM(CASE WHEN s.status='COMPLETED' THEN s.total ELSE 0 END),0),COALESCE(MAX(s.created_at),'') FROM customers cu LEFT JOIN sales s ON s.customer_id=cu.id GROUP BY cu.id ORDER BY cu.name COLLATE NOCASE").fetchall()
        self.customer_report_table.setRowCount(len(customers))
        for r,row in enumerate(customers):
            for j,v in enumerate(row): self.customer_report_table.setItem(r,j,QTableWidgetItem(str(v if v is not None else '')))
        c.close()

    def refresh_all(self): self.refresh_products(); self.refresh_customers(); self.refresh_suppliers(); self.refresh_purchases(); self.refresh_expenses(); self.refresh_reports(); self.refresh_employees(); self.refresh_data_reports()

    def clear_product_form(self):
        """Clear the editable product form without deleting or changing saved products."""
        self.edit_pid=None
        for w in (self.pb, self.pn, self.pc, self.pe):
            w.clear()
        self.pu.setText("pcs")
        for w in (self.pp, self.ps, self.pst, self.pmin, self.ptax):
            w.setValue(0)
        self.products_table.blockSignals(True)
        self.products_table.clearSelection()
        self.products_table.setCurrentCell(-1, -1)
        self.products_table.blockSignals(False)

    def refresh_products(self):
        # Refresh the saved product list from the database, but reset only the
        # editable form above. Existing/saved rows remain untouched.
        c=self.db(); rows=c.execute("SELECT id,barcode,name,category,purchase_price,selling_price,stock,min_stock,tax_rate,unit,expiry_date FROM products WHERE active=1 ORDER BY id DESC").fetchall(); c.close()
        self.products_table.blockSignals(True)
        self.products_table.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for j,v in enumerate(row): self.products_table.setItem(r,j,QTableWidgetItem(str(v)))
        self.products_table.blockSignals(False)
        self.clear_product_form()
        if hasattr(self, "product_search"):
            self.filter_products(self.product_search.text())

    def filter_products(self, text):
        q=text.strip().casefold()
        for row in range(self.products_table.rowCount()):
            values=[self.products_table.item(row,col).text() if self.products_table.item(row,col) else "" for col in (1,2,3)]
            self.products_table.setRowHidden(row, bool(q) and not any(q in value.casefold() for value in values))

    def filter_customers(self, text):
        q=text.strip().casefold()
        for row in range(self.ct.rowCount()):
            values=[self.ct.item(row,col).text() if self.ct.item(row,col) else "" for col in range(self.ct.columnCount())]
            self.ct.setRowHidden(row, bool(q) and not any(q in value.casefold() for value in values))

    def product_selected(self):
        items=self.products_table.selectedItems()
        if not items:return
        row=self.products_table.currentRow(); self.edit_pid=int(self.products_table.item(row,0).text()); vals=[self.products_table.item(row,i).text() for i in range(11)]
        self.pb.setText(vals[1]); self.pn.setText(vals[2]); self.pc.setText(vals[3]); self.pp.setValue(float(vals[4])); self.ps.setValue(float(vals[5])); self.pst.setValue(float(vals[6])); self.pmin.setValue(float(vals[7])); self.ptax.setValue(float(vals[8])); self.pu.setText(vals[9] or "pcs"); self.pe.setText(vals[10])

    def _prep_table(self,t):
        t.setEditTriggers(QAbstractItemView.NoEditTriggers); t.setSelectionBehavior(QAbstractItemView.SelectRows); t.setSelectionMode(QAbstractItemView.SingleSelection)

    def _safety_backup(self):
        try: backup_database(self.db_path,self.backup_dir)
        except Exception: pass

    def _confirm(self,title,msg):
        return QMessageBox.question(self,title,msg,QMessageBox.Yes|QMessageBox.No,QMessageBox.No)==QMessageBox.Yes

    def save_product(self):
        if not self.pn.text().strip(): return QMessageBox.warning(self,"Product","Name required")
        now=datetime.now().isoformat(timespec="seconds"); bc=self.pb.text().strip() or "AUTO"+datetime.now().strftime("%Y%m%d%H%M%S%f")
        exp=self.pe.text().strip()
        if exp:
            try: datetime.strptime(exp,"%Y-%m-%d")
            except ValueError: return QMessageBox.warning(self,"Product","Expiry date must look like 2026-12-31.")
        if self.ps.value()<self.pp.value() and not self._confirm("Product","Selling price is lower than purchase price (you will lose money on each sale). Save anyway?"): return
        c=self.db(); pid=getattr(self,"edit_pid",None)
        try:
            vals=(bc,self.pn.text().strip(),self.pc.text().strip(),self.pp.value(),self.ps.value(),self.pst.value(),self.pmin.value(),self.ptax.value(),self.pu.text().strip() or "pcs",exp)
            if pid:
                c.execute("UPDATE products SET barcode=?,name=?,category=?,purchase_price=?,selling_price=?,stock=?,min_stock=?,tax_rate=?,unit=?,expiry_date=?,updated_at=? WHERE id=?",vals+(now,pid)); c.commit(); self.log("PRODUCT_UPDATED",self.pn.text())
            else:
                c.execute("INSERT INTO products(barcode,name,category,purchase_price,selling_price,stock,min_stock,tax_rate,unit,expiry_date,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",vals+(now,now)); c.commit(); self.log("PRODUCT_CREATED",self.pn.text())
            self.refresh_all()
        except sqlite3.IntegrityError: QMessageBox.warning(self,"Product","This barcode is already used by another product.")
        except Exception as e: QMessageBox.warning(self,"Product",str(e))
        finally:c.close()

    def delete_product(self):
        row=self.products_table.currentRow()
        if row<0 or not self.products_table.item(row,0): return QMessageBox.warning(self,"Delete","Select a product first.")
        pid=int(self.products_table.item(row,0).text()); name=self.products_table.item(row,2).text()
        if not self._confirm("Delete product",f"Delete '{name}'?"): return
        self._safety_backup(); c=self.db()
        try:
            used=c.execute("SELECT (SELECT COUNT(*) FROM sale_items WHERE product_id=?)+(SELECT COUNT(*) FROM purchase_items WHERE product_id=?)",(pid,pid)).fetchone()[0]
            if used:
                # Product already appears on old bills: keep history intact, just remove it from the active list.
                c.execute("UPDATE products SET active=0,barcode=barcode||'~DEL'||id,updated_at=? WHERE id=?",(datetime.now().isoformat(timespec="seconds"),pid))
                QMessageBox.information(self,"Product removed","This product is on old bills, so it was removed from your product list and billing. Old bills and reports are not affected.")
            else:
                c.execute("DELETE FROM stock_movements WHERE product_id=?",(pid,)); c.execute("DELETE FROM products WHERE id=?",(pid,))
            c.commit(); self.log("PRODUCT_DELETED",name); self.refresh_all()
        except Exception as e:QMessageBox.warning(self,"Delete",str(e))
        finally:c.close()

    def _import_csv(self,title,fn,hint):
        path,_=QFileDialog.getOpenFileName(self,title,"","CSV files (*.csv)")
        if not path: return
        self._safety_backup(); c=self.db()
        try:
            added,updated,errors=fn(c,path); c.commit()
        except Exception as e:
            c.rollback(); c.close(); return QMessageBox.warning(self,title,f"Import failed: {e}\n\n{hint}")
        c.close(); self.log("CSV_IMPORT",f"{title}: added={added}, updated={updated}, errors={len(errors)}"); self.refresh_all()
        msg=f"Added: {added}\nUpdated: {updated}\nSkipped: {len(errors)}"
        if errors: msg+="\n\n"+"\n".join(errors[:8])
        QMessageBox.information(self,title,msg)
    def import_products(self):
        self._import_csv("Import products",services.import_products_csv,"First row must be headers: barcode,name,category,unit,purchase_price,selling_price,stock,min_stock,tax_rate,expiry_date")
    def import_customers(self):
        self._import_csv("Import customers",services.import_customers_csv,"First row must be headers: name,phone,email,address")

    def make_barcode(self):
        val=self.pb.text().strip() or "8901000000999"; self.pb.setText(val)
        path=generate_code128_pdf(val,self.db_path.parent/"barcodes"); QMessageBox.information(self,"Barcode PDF Generated",f"PDF saved:\n{path}")

    def add_scan_item(self):
        self._scan_timer.stop()
        q=self.scan.text().strip()
        if not q:return
        c=self.db(); row=c.execute("SELECT * FROM products WHERE barcode=? AND active=1 LIMIT 1",(q,)).fetchone()
        if not row: row=c.execute("SELECT * FROM products WHERE active=1 AND lower(name) LIKE lower(?) ORDER BY name LIMIT 1",(f"%{q}%",)).fetchone()
        c.close(); self.scan.clear(); self._scan_fast=0
        if not row:
            QMessageBox.warning(self,"Not found",f"Product not found: {q}"); self.scan.setFocus(); return
        if row["stock"]<=0:
            QMessageBox.warning(self,"Stock","Out of stock."); self.scan.setFocus(); return
        exp=(row["expiry_date"] or "").strip()
        if exp and exp<datetime.now().strftime("%Y-%m-%d") and not self._confirm("Expired product",f"{row['name']} expired on {exp}.\nAdd to bill anyway?"):
            self.scan.setFocus(); return
        qty=self.qty.value() or 1
        for i in self.cart:
            if i["id"]==row["id"]:
                if i["qty"]+qty>float(row["stock"]):
                    QMessageBox.warning(self,"Stock",f"Only {float(row['stock']):g} in stock."); self.scan.setFocus(); return
                i["qty"]+=qty; self.qty.setValue(1); self.render_cart(); self.scan.setFocus(); return
        if qty>float(row["stock"]):
            QMessageBox.warning(self,"Stock",f"Only {float(row['stock']):g} in stock."); self.scan.setFocus(); return
        self.cart.append(dict(id=row["id"],barcode=row["barcode"],name=row["name"],qty=qty,price=float(row["selling_price"]),tax=float(row["tax_rate"] or 0),stock=float(row["stock"]),cost=float(row["purchase_price"])))
        self.qty.setValue(1)
        self.render_cart(); self.scan.setFocus()

    def render_cart(self):
        self.cart_table.setRowCount(len(self.cart))
        for r,i in enumerate(self.cart):
            line=i["qty"]*i["price"]; tax=line*i["tax"]/100
            for j,v in enumerate([i["barcode"],i["name"],i["qty"],f"{i['price']:.2f}",f"{tax:.2f}",f"{line+tax:.2f}"]): self.cart_table.setItem(r,j,QTableWidgetItem(str(v)))
            controls=QWidget(); cl=QHBoxLayout(controls); cl.setContentsMargins(2,1,2,1); cl.setSpacing(3)
            minus=QPushButton("−"); minus.setObjectName("cartMinus"); minus.setFixedSize(26,25); minus.setToolTip("Decrease quantity")
            plus=QPushButton("+"); plus.setObjectName("cartPlus"); plus.setFixedSize(26,25); plus.setToolTip("Increase quantity")
            remove=QPushButton("×"); remove.setFixedSize(25,25); remove.setToolTip("Remove item")
            minus.clicked.connect(lambda _,row=r:self.change_cart_qty(row,-1)); plus.clicked.connect(lambda _,row=r:self.change_cart_qty(row,1)); remove.clicked.connect(lambda _,row=r:self.remove_cart_row(row))
            cl.addWidget(minus); cl.addWidget(plus); cl.addWidget(remove); self.cart_table.setCellWidget(r,6,controls)
        self.update_totals()


    def change_cart_qty(self,row,delta):
        if not (0 <= row < len(self.cart)): return
        item=self.cart[row]; new_qty=int(item['qty'])+delta
        if new_qty < 1:
            self.cart.pop(row)
        elif new_qty > item['stock']:
            QMessageBox.warning(self,"Stock",f"Only {item['stock']:.0f} units available."); return
        else:
            item['qty']=new_qty
        self.render_cart()

    def remove_cart_row(self,row):
        if 0 <= row < len(self.cart):
            self.cart.pop(row); self.render_cart()

    def adjust_cart_dialog(self,row):
        if not (0 <= row < len(self.cart)): return
        item=self.cart[row]
        qty,ok=QInputDialog.getInt(self,"Adjust item quantity",f"{item['name']} — current quantity {item['qty']}\nEnter 0 to remove this item:",int(item['qty']),0,9999)
        if not ok: return
        if qty==0: self.cart.pop(row)
        elif qty>item['stock']:
            QMessageBox.warning(self,"Stock",f"Only {item['stock']:.0f} units available."); return
        else: item['qty']=qty
        self.render_cart()

    def change_scan_qty(self,delta):
        self.qty.setValue(max(self.qty.minimum(), min(self.qty.maximum(), self.qty.value()+delta)))

    def _disc_type_changed(self,*_):
        pct=self.disc_type.currentText()=="%"
        self.discount.blockSignals(True); self.discount.setValue(0)
        if pct: self.discount.setPrefix(""); self.discount.setSuffix(" %"); self.discount.setMaximum(100)
        else: self.discount.setSuffix(""); self.discount.setPrefix("₹ "); self.discount.setMaximum(1e9)
        self.discount.blockSignals(False); self.update_totals()

    def _discount_amount(self,base):
        return services.apply_discount(base,self.discount.value(),self.disc_type.currentText()=="%")

    def _customer_lookup(self,text):
        text=text.strip()
        if len(text)<6: self.cust_info.setText(""); return
        c=self.db(); r=c.execute("SELECT name,points,credit_balance FROM customers WHERE phone=? LIMIT 1",(text,)).fetchone(); c.close()
        self.cust_info.setText(f"✔ {r['name']}  •  {r['points']:g} points" if r else "New customer — will be saved with this bill")

    def _collect_payment(self,total):
        """Ask for cash received / split amounts. Returns (list of (method, amount), change) or (None, 0) if cancelled."""
        method=self.payment.currentText()
        if method=="Cash":
            got,ok=QInputDialog.getDouble(self,"Cash payment",f"Total  ₹ {total:.2f}\nCash received from customer:",round(total,2),round(total,2),1e9,2)
            return ([("Cash",round(total,2))],round(got-total,2)) if ok else (None,0)
        if method=="Split":
            cash,ok=QInputDialog.getDouble(self,"Split payment",f"Total  ₹ {total:.2f}\nAmount paid in CASH (rest will be paid by the next method):",0,0,round(total,2),2)
            if not ok: return None,0
            other="UPI"
            if cash<total:
                other,ok=QInputDialog.getItem(self,"Split payment",f"Pay the remaining ₹ {total-cash:.2f} by:",["UPI","Card","Wallet"],0,False)
                if not ok: return None,0
            return services.split_payment(total,"Cash",cash,other),0
        return [(method,round(total,2))],0

    def update_totals(self):
        sub=sum(i["qty"]*i["price"] for i in self.cart); tax=sum(i["qty"]*i["price"]*i["tax"]/100 for i in self.cart); dis=self._discount_amount(sub+tax); total=sub+tax-dis
        self.summary.setText(f"Subtotal  ₹ {sub:.2f}\nTax       ₹ {tax:.2f}\nDiscount  ₹ {dis:.2f}\n\nTOTAL     ₹ {total:.2f}")

    def adjust_cart_qty(self,row,delta):
        if not (0 <= row < len(self.cart)): return
        item=self.cart[row]; new_qty=item["qty"]+delta
        if new_qty < 1: self.cart.pop(row)
        elif new_qty > item["stock"]: QMessageBox.warning(self,"Stock",f"Only {item['stock']:.0f} units available."); return
        else: item["qty"]=new_qty
        self.render_cart()

    def remove_selected(self):
        r=self.cart_table.currentRow()
        if 0<=r<len(self.cart):self.cart.pop(r);self.render_cart()
    def clear_cart(self): self.cart=[]; self.discount.setValue(0); self.render_cart()
    def hold_bill(self):
        if self.cart:self.held.append((self.cart[:],self.customer.text(),self.discount.value(),self.payment.currentText())); self.clear_cart(); QMessageBox.information(self,"Held","Bill held.")
    def resume_bill(self):
        if not self.held:return
        self.cart,self.customer_name,self.dis,self.pay=self.held.pop()
        self.disc_type.setCurrentIndex(0); self.customer.setText(self.customer_name); self.discount.setValue(self.dis); self.payment.setCurrentText(self.pay); self.render_cart()

    def checkout(self):
        if not self.cart:
            return QMessageBox.warning(self,"Billing","Cart is empty.")
        c=self.db(); now=datetime.now(); sub=sum(i["qty"]*i["price"] for i in self.cart); tax=sum(i["qty"]*i["price"]*i["tax"]/100 for i in self.cart); dis=self._discount_amount(sub+tax); total=round(sub+tax-dis,2); inv="INV-"+now.strftime("%Y%m%d-%H%M%S-%f")[:-3]
        pay_parts,change=self._collect_payment(total)
        if pay_parts is None: c.close(); return
        earned_points=0
        try:
            customer_phone=self.customer.text().strip(); cid=None
            if customer_phone:
                row=c.execute("SELECT id FROM customers WHERE phone=? LIMIT 1",(customer_phone,)).fetchone()
                if row:
                    cid=row["id"]
                else:
                    cid=c.execute("INSERT INTO customers(name,phone,created_at) VALUES(?,?,?)",(f"Customer {customer_phone}",customer_phone,now.isoformat(timespec="seconds"))).lastrowid
            emp=c.execute("SELECT id FROM employees WHERE username=? LIMIT 1",(self.current_user,)).fetchone()
            eid=emp["id"] if emp else None
            sid=c.execute("INSERT INTO sales(invoice_no,customer_id,employee_id,subtotal,discount,tax,total,payment_method,created_at,session_no) VALUES(?,?,?,?,?,?,?,?,?,?)",(inv,cid,eid,sub,dis,tax,total,self.payment.currentText(),now.isoformat(timespec="seconds"),getattr(self,"session_no",""))).lastrowid
            for i in self.cart:
                line=i["qty"]*i["price"]; c.execute("INSERT INTO sale_items(sale_id,product_id,quantity,price,tax_rate,line_total,cost) VALUES(?,?,?,?,?,?,?)",(sid,i["id"],i["qty"],i["price"],i["tax"],line,i["cost"]))
                if c.execute("UPDATE products SET stock=stock-?,updated_at=? WHERE id=? AND stock>=?",(i["qty"],now.isoformat(timespec="seconds"),i["id"],i["qty"])).rowcount==0: raise ValueError(f"Not enough stock for {i['name']}. Refresh and try again.")
                c.execute("INSERT INTO stock_movements(product_id,type,quantity,reference,created_at) VALUES(?,?,?,?,?)",(i["id"],"SALE",-i["qty"],inv,now.isoformat(timespec="seconds")))
            if cid is not None:
                earned_points=sum(float(i["qty"]) for i in self.cart)
                c.execute("UPDATE customers SET points=points+? WHERE id=?",(earned_points,cid))
            for pm,amt in pay_parts: c.execute("INSERT INTO payments(sale_id,payment_method,amount,created_at) VALUES(?,?,?,?)",(sid,pm,amt,now.isoformat(timespec="seconds")))
            c.commit(); self.last_invoice=inv; self.last_sale_id=sid
        except Exception as e:
            c.rollback(); c.close(); return QMessageBox.critical(self,"Checkout",str(e))
        c.close()
        try:
            pdf_path=self.create_invoice_pdf(inv)
            self.archive_invoice_pdf(inv,self.last_sale_id,pdf_path)
        except Exception as e:
            self.log("INVOICE_PDF_ERROR",f"{inv}; {e}")
            pdf_path=None
        self.log("SALE_COMPLETED",f"{inv}; points_earned={earned_points:g}; pdf_archived={bool(pdf_path)}")
        # Checkout sends the invoice straight to the configured OS printer; no extra print dialog.
        # A PDF copy is retained in exports/database for records and reprints.
        if self.get_meta("print_auto","1")=="1":
            if not self.print_invoice(inv, silent=True):
                QMessageBox.warning(self,"Printer",f"Bill {inv} is saved, but it could not be printed:\n{getattr(self,'last_print_error','')}\n\nCheck More > Printer Setup, then press PRINT LAST BILL.")
        self.clear_cart(); self.customer.clear(); self.refresh_all()
        if change>0: QMessageBox.information(self,"Change to return",f"Bill total  ₹ {total:.2f}\n\nCHANGE TO RETURN:   ₹ {change:.2f}")
        self.scan.setFocus()

    def _invoice_rows(self, inv):
        c=self.db(); s=c.execute("SELECT * FROM sales WHERE invoice_no=?",(inv,)).fetchone()
        if not s: c.close(); return None,[]
        items=c.execute("SELECT si.*,p.name,p.barcode FROM sale_items si JOIN products p ON p.id=si.product_id WHERE si.sale_id=? ORDER BY si.id",(s["id"],)).fetchall(); c.close(); return s,items

    def _maybe_auto_scan(self, text):
        """USB/Bluetooth scanners type like a keyboard, very fast (a few ms per character).
        When a burst of fast characters stops, the product is added automatically even if the scanner sends no Enter."""
        now=time.perf_counter(); gap=now-self._scan_last; self._scan_last=now
        self._scan_fast=self._scan_fast+1 if (len(text)>1 and gap<0.06) else 1
        if self.scanner_auto and len(text.strip())>=self.scanner_minlen and self._scan_fast>=self.scanner_minlen-1:
            self._scan_timer.start(150)
        else:
            self._scan_timer.stop()

    def create_invoice_pdf(self, inv):
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
        out=self.db_path.parent/"exports"/f"{inv}.pdf"; out.parent.mkdir(parents=True,exist_ok=True)
        s,items=self._invoice_rows(inv)
        if not s: raise ValueError("Invoice not found")
        c=canvas.Canvas(str(out),pagesize=A4); w,h=A4; y=h-45
        sh=self._shop(); c.setFont("Helvetica-Bold",20); c.drawString(45,y,f"{sh['name']} — TAX INVOICE"); y-=18
        sub_line=" | ".join(x for x in [sh["address"],("Ph: "+sh["phone"]) if sh["phone"] else "",("GSTIN: "+sh["gstin"]) if sh["gstin"] else ""] if x)
        if sub_line: c.setFont("Helvetica",9); c.drawString(45,y,sub_line.encode("latin-1","replace").decode("latin-1")); y-=14
        y-=8
        c.setFont("Helvetica",10); c.drawString(45,y,f"Invoice: {inv}"); c.drawRightString(w-45,y,f"Date: {s['created_at']}"); y-=18
        customer_phone=""
        if s["customer_id"]:
            cc=self.db(); cr=cc.execute("SELECT phone FROM customers WHERE id=?",(s["customer_id"],)).fetchone(); cc.close(); customer_phone=cr["phone"] if cr else ""
        c.drawString(45,y,f"Customer Phone: {customer_phone or 'Walk-in Customer'}"); y-=20
        c.line(45,y,w-45,y); y-=20
        c.setFont("Helvetica-Bold",10); c.drawString(45,y,"Product"); c.drawString(285,y,"Qty"); c.drawString(335,y,"Price"); c.drawString(405,y,"Tax"); c.drawRightString(w-45,y,"Amount"); y-=16
        c.setFont("Helvetica",9)
        for i in items:
            if y<80: c.showPage(); y=h-45
            name=str(i["name"])[:34]; qty=float(i["quantity"]); price=float(i["price"]); tax=float(i["line_total"])*float(i["tax_rate"] or 0)/100; amount=float(i["line_total"])+tax
            c.drawString(45,y,name); c.drawRightString(315,y,f"{qty:g}"); c.drawRightString(390,y,f"Rs.{price:.2f}"); c.drawRightString(455,y,f"Rs.{tax:.2f}"); c.drawRightString(w-45,y,f"Rs.{amount:.2f}"); y-=15
        y-=8; c.line(300,y,w-45,y); y-=18; c.setFont("Helvetica",10)
        c.drawRightString(w-45,y,f"Subtotal: Rs.{s['subtotal']:.2f}"); y-=15; c.drawRightString(w-45,y,f"Tax: Rs.{s['tax']:.2f}"); y-=15; c.drawRightString(w-45,y,f"Discount: Rs.{s['discount']:.2f}"); y-=18
        c.setFont("Helvetica-Bold",13); c.drawRightString(w-45,y,f"TOTAL: Rs.{s['total']:.2f}"); y-=20; c.setFont("Helvetica",10); c.drawString(45,y,f"Payment: {s['payment_method']}"); y-=16; c.drawString(45,y,"Loyalty points earned: calculated per purchased unit"); y-=16; c.drawString(45,y,"Thank you for shopping with RUBIX$."); c.save(); return str(out)

    def archive_invoice_pdf(self, inv, sale_id, pdf_path):
        data=Path(pdf_path).read_bytes(); c=self.db(); c.execute("INSERT OR REPLACE INTO invoice_documents(sale_id,invoice_no,pdf_path,pdf_blob,created_at) VALUES(?,?,?,?,?)",(sale_id,inv,str(pdf_path),data,datetime.now().isoformat(timespec="seconds"))); c.commit(); c.close()

    def _printer_info(self):
        name=self.get_meta("printer_name","")
        info=None
        if name:
            for pi in QPrinterInfo.availablePrinters():
                if pi.printerName()==name: info=pi; break
        if info is None: info=QPrinterInfo.defaultPrinter()
        if info.isNull():
            raise RuntimeError("No printer found. Install/connect your printer and choose it in More > Printer Setup.")
        return info

    def _print_html(self, html, rows=10):
        """Send an HTML document to the chosen printer using the chosen paper (A4 or 80mm/58mm receipt)."""
        info=self._printer_info(); paper=self.get_meta("paper_size","A4")
        printer=QPrinter(QPrinter.HighResolution); printer.setPrinterName(info.printerName())
        if paper.startswith("Receipt"):
            width=80 if "80" in paper else 58
            printer.setPageSize(QPageSize(QSizeF(width,max(120,70+8*rows)),QPageSize.Millimeter))
            printer.setPageMargins(QMarginsF(3,3,3,3),QPageLayout.Millimeter)
        document=QTextDocument(); document.setHtml(html); document.print_(printer)
        return info.printerName()

    def _shop(self):
        return {k:self.get_meta("shop_"+k,d) for k,d in [("name","RUBIX$"),("address",""),("phone",""),("gstin",""),("footer","Thank you! Visit again.")]}

    def _shop_header(self):
        sh=self._shop(); e=_html.escape
        line=" | ".join(x for x in [sh["address"],("Ph: "+sh["phone"]) if sh["phone"] else "",("GSTIN: "+sh["gstin"]) if sh["gstin"] else ""] if x)
        return f"<h2 align='center'>{e(sh['name'])}</h2>"+(f"<p align='center'>{e(line)}</p>" if line else "")

    def shop_setup(self):
        dlg=QDialog(self); dlg.setWindowTitle("Store Details"); dlg.setMinimumWidth(460); lay=QVBoxLayout(dlg); f=QFormLayout(); lay.addLayout(f)
        w={k:QLineEdit(v) for k,v in self._shop().items()}
        for k,lab in [("name","Store name"),("address","Address"),("phone","Phone"),("gstin","GSTIN"),("footer","Bill footer message")]: f.addRow(lab,w[k])
        def save():
            for k,x in w.items(): self.set_meta("shop_"+k,x.text().strip())
            self.log("STORE_DETAILS_UPDATED",""); dlg.accept()
        row=QHBoxLayout(); row.addStretch(); [row.addWidget(self.btn(t,fn)) for t,fn in [("SAVE",save),("CANCEL",dlg.reject)]]; lay.addLayout(row); dlg.exec()

    def _invoice_html(self, inv, sale, items):
        paper=self.get_meta("paper_size","A4"); e=_html.escape
        if paper.startswith("Receipt"):
            fs="8pt" if "58" in paper else "9pt"
            rows="".join(f"<tr><td colspan='3'>{e(str(i['name']))}</td></tr><tr><td>{float(i['quantity']):g} x {float(i['price']):.2f}</td><td align='right'>{float(i['line_total'])*float(i['tax_rate'] or 0)/100:.2f}</td><td align='right'>{float(i['line_total'])*(1+float(i['tax_rate'] or 0)/100):.2f}</td></tr>" for i in items)
            return f"""<html><body style='font-family:Arial;color:#000;font-size:{fs}'>
            {self._shop_header()}<p align='center'>TAX INVOICE</p><p>Bill: {e(inv)}<br>Date: {e(str(sale['created_at']))}<br>Pay: {e(str(sale['payment_method']))}</p>
            <table width='100%' cellspacing='0' cellpadding='1'><tr><th align='left'>Qty x Price</th><th align='right'>GST</th><th align='right'>Total</th></tr>{rows}</table><hr>
            <p align='right'>Subtotal: {float(sale['subtotal']):.2f}<br>GST: {float(sale['tax']):.2f}<br>Discount: {float(sale['discount']):.2f}<br><b>TOTAL: {float(sale['total']):.2f}</b></p>
            <p align='center'>{e(self._shop()['footer'])}</p></body></html>"""
        rows=[]
        for item in items:
            qty=float(item["quantity"]); price=float(item["price"]); tax=float(item["line_total"])*float(item["tax_rate"] or 0)/100
            rows.append(f"<tr><td>{e(str(item['name']))}</td><td align='right'>{qty:g}</td><td align='right'>{price:.2f}</td><td align='right'>{tax:.2f}</td><td align='right'>{float(item['line_total'])+tax:.2f}</td></tr>")
        return f"""<html><body style='font-family:Arial;color:#000;font-size:10pt'>
            {self._shop_header()}<h3 align='center'>TAX INVOICE</h3><p>Invoice: {e(inv)}<br>Date: {e(str(sale['created_at']))}<br>Payment: {e(str(sale['payment_method']))}</p>
            <table width='100%' border='1' cellspacing='0' cellpadding='5'><tr><th>Product</th><th>Qty</th><th>Price</th><th>Tax</th><th>Total</th></tr>{''.join(rows)}</table>
            <p align='right'>Subtotal: ₹{float(sale['subtotal']):.2f}<br>Tax: ₹{float(sale['tax']):.2f}<br>Discount: ₹{float(sale['discount']):.2f}<br><b>TOTAL: ₹{float(sale['total']):.2f}</b></p>
            <p align='center'>{e(self._shop()['footer'])}</p></body></html>"""

    def print_invoice(self, inv, silent=False):
        """Print an invoice directly to the selected printer without opening a PDF viewer."""
        try:
            sale, items = self._invoice_rows(inv)
            if not sale:
                raise ValueError("Invoice not found")
            name=self._print_html(self._invoice_html(inv,sale,items), len(items))
            self.log("BILL_PRINTED", f"{inv}; printer={name}")
            if not silent:
                QMessageBox.information(self, "Print bill", f"Bill sent to printer: {name}")
            return True
        except Exception as e:
            self.last_print_error=str(e)
            self.log("BILL_PRINT_ERROR", f"{inv}; {e}")
            if not silent:
                QMessageBox.warning(self, "Printer", str(e))
            return False

    def reprint_last(self):
        inv=getattr(self,"last_invoice",None)
        if not inv:
            c=self.db(); r=c.execute("SELECT invoice_no FROM sales ORDER BY id DESC LIMIT 1").fetchone(); c.close(); inv=r["invoice_no"] if r else None
        if not inv: return QMessageBox.information(self,"Print","No bill to print yet.")
        self.print_invoice(inv, silent=False)

    def printer_setup(self):
        dlg=QDialog(self); dlg.setWindowTitle("Printer Setup"); dlg.setMinimumWidth(480)
        lay=QVBoxLayout(dlg); lay.setContentsMargins(22,20,22,18); lay.setSpacing(12)
        printers=[pi.printerName() for pi in QPrinterInfo.availablePrinters()]
        dflt=QPrinterInfo.defaultPrinter(); dname="" if dflt.isNull() else dflt.printerName()
        pc=QComboBox(); pc.addItem("System default printer"+(f"  ({dname})" if dname else ""),"")
        for n in printers: pc.addItem(n,n)
        pc.setCurrentIndex(max(0,pc.findData(self.get_meta("printer_name",""))))
        paper=QComboBox(); paper.addItems(["A4","Receipt 80mm","Receipt 58mm"]); paper.setCurrentText(self.get_meta("paper_size","A4"))
        auto=QCheckBox("Print the bill automatically after checkout"); auto.setChecked(self.get_meta("print_auto","1")=="1")
        form=QFormLayout(); form.addRow("Printer",pc); form.addRow("Paper",paper); lay.addLayout(form); lay.addWidget(auto)
        note=QLabel("Printers found: "+(", ".join(printers) if printers else "none — connect/install a printer driver in Windows first."))
        note.setWordWrap(True); lay.addWidget(note)
        def store():
            self.set_meta("printer_name",pc.currentData() or ""); self.set_meta("paper_size",paper.currentText()); self.set_meta("print_auto","1" if auto.isChecked() else "0")
        def test():
            store()
            try:
                name=self._print_html("<html><body style='font-family:Arial;color:#000'><h2 align='center'>RUBIX$</h2><p align='center'>Printer test OK</p><p align='center'>"+_html.escape(datetime.now().strftime("%d-%m-%Y %H:%M:%S"))+"</p></body></html>",3)
                QMessageBox.information(dlg,"Test print",f"Test page sent to: {name}")
            except Exception as e:
                QMessageBox.warning(dlg,"Printer",str(e))
        def save(): store(); dlg.accept()
        row=QHBoxLayout(); row.addStretch()
        for text,fn in [("TEST PRINT",test),("SAVE",save),("CANCEL",dlg.reject)]: row.addWidget(self.btn(text,fn))
        lay.addLayout(row); dlg.exec()

    def scanner_setup(self):
        dlg=QDialog(self); dlg.setWindowTitle("Scanner Setup"); dlg.setMinimumWidth(500)
        lay=QVBoxLayout(dlg); lay.setContentsMargins(22,20,22,18); lay.setSpacing(12)
        info=QLabel("USB / Bluetooth barcode scanners work like a keyboard. Click the box below and scan any barcode to test it."); info.setWordWrap(True); lay.addWidget(info)
        test=QLineEdit(); test.setPlaceholderText("Scan a barcode here…"); lay.addWidget(test)
        result=QLabel("Waiting for a scan…"); result.setWordWrap(True); lay.addWidget(result)
        test.textChanged.connect(lambda t: result.setText(f"Received: {t}   ({len(t)} characters)") if t else None)
        test.returnPressed.connect(lambda: (result.setText(f"✔ Scanner OK — received “{test.text()}” and the Enter key"), test.clear()))
        auto=QCheckBox("Add the product automatically right after a scan (no Enter key needed)"); auto.setChecked(self.scanner_auto); lay.addWidget(auto)
        minlen=QSpinBox(); minlen.setRange(3,30); minlen.setValue(self.scanner_minlen); minlen.setButtonSymbols(QAbstractSpinBox.UpDownArrows)
        form=QFormLayout(); form.addRow("Minimum barcode length for auto-add",minlen); lay.addLayout(form)
        def save():
            self.set_meta("scanner_auto","1" if auto.isChecked() else "0"); self.set_meta("scanner_minlen",minlen.value())
            self.scanner_auto=auto.isChecked(); self.scanner_minlen=minlen.value(); dlg.accept()
        row=QHBoxLayout(); row.addStretch()
        for text,fn in [("SAVE",save),("CANCEL",dlg.reject)]: row.addWidget(self.btn(text,fn))
        lay.addLayout(row); test.setFocus(); dlg.exec(); self.scan.setFocus()

    def change_purchase_qty(self,delta):
        self.purchase_qty.setValue(max(self.purchase_qty.minimum(), self.purchase_qty.value()+delta))

    def return_sale(self):
        inv=QInputDialog.getText(self,"Return","Enter invoice number")[0].strip()
        if not inv:return
        c=self.db(); s=c.execute("SELECT * FROM sales WHERE invoice_no=?",(inv,)).fetchone()
        if not s:return QMessageBox.warning(self,"Return","Invoice not found.")
        if s["status"]=="RETURNED":return QMessageBox.warning(self,"Return","Already returned.")
        reason=QInputDialog.getText(self,"Return","Reason")[0] or "Customer return"
        now=datetime.now().isoformat(timespec="seconds"); c.execute("UPDATE sales SET status='RETURNED' WHERE id=?",(s["id"],))
        items=c.execute("SELECT * FROM sale_items WHERE sale_id=?",(s["id"],)).fetchall()
        for i in items:c.execute("UPDATE products SET stock=stock+? WHERE id=?",(i["quantity"],i["product_id"])); c.execute("INSERT INTO stock_movements(product_id,type,quantity,reference,created_at) VALUES(?,?,?,?,?)",(i["product_id"],"RETURN",i["quantity"],inv,now))
        c.execute("INSERT INTO returns(return_no,sale_id,customer_id,total,reason,created_at) VALUES(?,?,?,?,?,?)",("RET-"+datetime.now().strftime("%Y%m%d%H%M%S"),s["id"],s["customer_id"],s["total"],reason,now)); c.commit(); c.close(); self.log("SALE_RETURNED",inv); self.refresh_all(); QMessageBox.information(self,"Return","Return completed and stock restored.")

    def export_invoice(self):
        inv=getattr(self,"last_invoice",None)
        if not inv:return QMessageBox.information(self,"Invoice","Complete a sale first.")
        pdf_path=self.db_path.parent/"exports"/f"{inv}.pdf"
        if not pdf_path.exists():
            try: pdf_path=self.create_invoice_pdf(inv)
            except Exception as e: return QMessageBox.critical(self,"Invoice PDF",str(e))
        c=self.db(); row=c.execute("SELECT id FROM sales WHERE invoice_no=?",(inv,)).fetchone(); c.close()
        if row: self.archive_invoice_pdf(inv,row["id"],pdf_path)
        QMessageBox.information(self,"Invoice PDF",f"PDF copy saved and archived:\n{pdf_path}")

    def sign_out(self):
        self.log("SIGNED_OUT",self.current_user)
        dlg=LoginDialog(self.db_path,self)
        self.hide()
        if dlg.exec()==QDialog.Accepted:
            self.current_user=dlg.user["username"]; self.current_role=dlg.user["role"]; self.current_name=dlg.user["name"]
            self.build_ui(); self.refresh_all(); self.showFullScreen()
        else:
            self.close()

    def save_customer(self):
        if not self.cn.text().strip(): return QMessageBox.warning(self,"Customer","Name required")
        c=self.db(); cid=getattr(self,"edit_cid",None); v=(self.cn.text().strip(),self.cp.text().strip(),self.ce.text().strip(),self.ca.text().strip())
        if cid: c.execute("UPDATE customers SET name=?,phone=?,email=?,address=? WHERE id=?",v+(cid,))
        else: c.execute("INSERT INTO customers(name,phone,email,address,created_at) VALUES(?,?,?,?,?)",v+(datetime.now().isoformat(timespec="seconds"),))
        c.commit(); c.close(); self.log("CUSTOMER_SAVED",v[0]); self.refresh_customers(); self.clear_customer_form()
    def clear_customer_form(self):
        self.edit_cid=None
        for w in (self.cn,self.cp,self.ce,self.ca): w.clear()
        self.ct.clearSelection()
    def customer_selected(self):
        r=self.ct.currentRow()
        if r<0 or not self.ct.item(r,0): return
        self.edit_cid=int(self.ct.item(r,0).text()); c=self.db(); x=c.execute("SELECT name,phone,email,address FROM customers WHERE id=?",(self.edit_cid,)).fetchone(); c.close()
        if x: self.cn.setText(x["name"]); self.cp.setText(x["phone"]); self.ce.setText(x["email"]); self.ca.setText(x["address"])
    def delete_customer(self):
        cid=getattr(self,"edit_cid",None)
        if not cid: return QMessageBox.warning(self,"Delete","Select a customer first.")
        if not self._confirm("Delete customer","Delete this customer? Their old bills stay in reports and will show as Walk-in."): return
        self._safety_backup(); c=self.db()
        try:
            c.execute("UPDATE sales SET customer_id=NULL WHERE customer_id=?",(cid,)); c.execute("UPDATE returns SET customer_id=NULL WHERE customer_id=?",(cid,)); c.execute("DELETE FROM customers WHERE id=?",(cid,)); c.commit(); self.log("CUSTOMER_DELETED",f"id={cid}")
        except Exception as e: QMessageBox.warning(self,"Delete",str(e))
        finally: c.close()
        self.clear_customer_form(); self.refresh_all()
    def refresh_customers(self):
        c=self.db(); rows=c.execute("SELECT id,name,phone,email,membership,points,credit_balance FROM customers ORDER BY id DESC").fetchall(); c.close(); self.ct.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for j,v in enumerate(row):self.ct.setItem(r,j,QTableWidgetItem(str(v)))
        if hasattr(self, "customer_search"):
            self.filter_customers(self.customer_search.text())
    def save_supplier(self):
        if not self.sn.text().strip(): return QMessageBox.warning(self,"Supplier","Name required")
        c=self.db(); sid=getattr(self,"edit_sid",None); v=(self.sn.text().strip(),self.sp.text().strip(),self.se.text().strip(),self.sa.text().strip())
        if sid: c.execute("UPDATE suppliers SET name=?,phone=?,email=?,address=? WHERE id=?",v+(sid,))
        else: c.execute("INSERT INTO suppliers(name,phone,email,address,created_at) VALUES(?,?,?,?,?)",v+(datetime.now().isoformat(timespec="seconds"),))
        c.commit(); c.close(); self.log("SUPPLIER_SAVED",v[0]); self.refresh_suppliers(); self.clear_supplier_form()
    def _fill_supplier_combo(self,rows):
        if not hasattr(self,"purchase_supplier"): return
        cur=self.purchase_supplier.currentData(); self.purchase_supplier.clear(); self.purchase_supplier.addItem("— No supplier —",None)
        for r in rows: self.purchase_supplier.addItem(r["name"],r["id"])
        i=self.purchase_supplier.findData(cur)
        if i>=0: self.purchase_supplier.setCurrentIndex(i)
    def clear_supplier_form(self):
        self.edit_sid=None
        for w in (self.sn,self.sp,self.se,self.sa): w.clear()
        self.st.clearSelection()
    def supplier_selected(self):
        r=self.st.currentRow()
        if r<0 or not self.st.item(r,0): return
        self.edit_sid=int(self.st.item(r,0).text()); c=self.db(); x=c.execute("SELECT name,phone,email,address FROM suppliers WHERE id=?",(self.edit_sid,)).fetchone(); c.close()
        if x: self.sn.setText(x["name"]); self.sp.setText(x["phone"]); self.se.setText(x["email"]); self.sa.setText(x["address"])
    def pay_supplier_balance(self):
        sid=getattr(self,"edit_sid",None)
        if not sid: return QMessageBox.warning(self,"Supplier","Select a supplier first.")
        c=self.db(); row=c.execute("SELECT name,balance FROM suppliers WHERE id=?",(sid,)).fetchone()
        if not row or row["balance"]<=0: c.close(); return QMessageBox.information(self,"Supplier","No pending balance for this supplier.")
        amt,ok=QInputDialog.getDouble(self,"Pay supplier",f"{row['name']} — pending ₹{row['balance']:.2f}\nAmount paying now:",row["balance"],0.01,row["balance"],2)
        if not ok: c.close(); return
        paid=services.pay_supplier(c,sid,amt); c.commit(); c.close(); self.log("SUPPLIER_PAID",f"id={sid}; amount={paid:.2f}"); self.refresh_all()
    def delete_supplier(self):
        sid=getattr(self,"edit_sid",None)
        if not sid: return QMessageBox.warning(self,"Delete","Select a supplier first.")
        if not self._confirm("Delete supplier","Delete this supplier?"): return
        self._safety_backup(); c=self.db()
        try: c.execute("UPDATE purchases SET supplier_id=NULL WHERE supplier_id=?",(sid,)); c.execute("DELETE FROM suppliers WHERE id=?",(sid,)); c.commit(); self.log("SUPPLIER_DELETED",f"id={sid}")
        except Exception as e: QMessageBox.warning(self,"Delete",str(e))
        finally: c.close()
        self.clear_supplier_form(); self.refresh_suppliers()
    def refresh_suppliers(self):
        c=self.db(); rows=c.execute("SELECT id,name,phone,email,address,balance FROM suppliers ORDER BY id DESC").fetchall(); c.close(); self.st.setRowCount(len(rows)); self._fill_supplier_combo(rows)
        for r,row in enumerate(rows):
            for j,v in enumerate(row):self.st.setItem(r,j,QTableWidgetItem(str(v)))
    def stock_in(self):
        q=self.purchase_product.text().strip(); c=self.db(); p=c.execute("SELECT * FROM products WHERE active=1 AND (barcode=? OR lower(name) LIKE lower(?)) LIMIT 1",(q,f"%{q}%")).fetchone()
        if not p:c.close(); return QMessageBox.warning(self,"Stock In","Product not found.")
        qty=self.purchase_qty.value(); cost=self.purchase_cost.value() or p["purchase_price"]
        try:
            inv,total=services.record_purchase(c,self.purchase_supplier.currentData(),[(p["id"],qty,cost)],self.purchase_pay.currentText()); c.commit()
        except Exception as e:
            c.rollback(); c.close(); return QMessageBox.warning(self,"Stock In",str(e))
        c.close(); self.log("STOCK_IN",f"{inv}; {p['name']} x{qty:g}; total={total:.2f}"); self.purchase_product.clear(); self.purchase_qty.setValue(1); self.purchase_cost.setValue(0); self.refresh_all()
        QMessageBox.information(self,"Stock In",f"{p['name']}: +{qty:g} added.\nPurchase bill {inv}  (₹ {total:.2f})")
    def refresh_purchases(self):
        c=self.db(); rows=c.execute("SELECT p.id,p.name,p.barcode,p.stock,p.purchase_price,p.selling_price,p.expiry_date FROM products p WHERE p.active=1 ORDER BY p.id DESC").fetchall(); c.close(); self.pt.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for j,v in enumerate(row):self.pt.setItem(r,j,QTableWidgetItem(str(v)))
    def save_expense(self):
        if self.ea.value()<=0: return QMessageBox.warning(self,"Expense","Amount must be more than 0")
        c=self.db(); eid=getattr(self,"edit_eid",None); v=(self.ec.text().strip() or "General",self.ed.text().strip(),self.ea.value(),self.ep.currentText())
        if eid: c.execute("UPDATE expenses SET category=?,description=?,amount=?,payment_method=? WHERE id=?",v+(eid,))
        else: c.execute("INSERT INTO expenses(category,description,amount,payment_method,created_at) VALUES(?,?,?,?,?)",v+(datetime.now().isoformat(timespec="seconds"),))
        c.commit(); c.close(); self.log("EXPENSE_SAVED",v[0]); self.refresh_expenses(); self.clear_expense_form()
    def clear_expense_form(self):
        self.edit_eid=None; self.ec.clear(); self.ed.clear(); self.ea.setValue(0); self.ep.setCurrentIndex(0); self.et.clearSelection()
    def expense_selected(self):
        r=self.et.currentRow()
        if r<0 or not self.et.item(r,0): return
        self.edit_eid=int(self.et.item(r,0).text()); c=self.db(); x=c.execute("SELECT category,description,amount,payment_method FROM expenses WHERE id=?",(self.edit_eid,)).fetchone(); c.close()
        if x: self.ec.setText(x["category"]); self.ed.setText(x["description"]); self.ea.setValue(x["amount"]); self.ep.setCurrentText(x["payment_method"])
    def delete_expense(self):
        eid=getattr(self,"edit_eid",None)
        if not eid: return QMessageBox.warning(self,"Delete","Select an expense first.")
        if not self._confirm("Delete expense","Delete this expense?"): return
        self._safety_backup(); c=self.db(); c.execute("DELETE FROM expenses WHERE id=?",(eid,)); c.commit(); c.close(); self.log("EXPENSE_DELETED",f"id={eid}"); self.clear_expense_form(); self.refresh_expenses()
    def refresh_expenses(self):
        c=self.db(); rows=c.execute("SELECT id,category,description,amount,created_at FROM expenses ORDER BY id DESC LIMIT 100").fetchall(); c.close(); self.et.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for j,v in enumerate(row):self.et.setItem(r,j,QTableWidgetItem(str(v)))

    def refresh_reports(self):
        c=self.db(); today=datetime.now().strftime("%Y-%m-%d"); s=c.execute("SELECT COUNT(*) n,COALESCE(SUM(total),0) total,COALESCE(SUM(subtotal-discount),0) net FROM sales WHERE date(created_at)=? AND status='COMPLETED'",(today,)).fetchone()
        profit=c.execute("SELECT COALESCE(SUM(si.quantity*(si.price-COALESCE(NULLIF(si.cost,0),p.purchase_price))),0) FROM sale_items si JOIN products p ON p.id=si.product_id JOIN sales s ON s.id=si.sale_id WHERE date(s.created_at)=? AND s.status='COMPLETED'",(today,)).fetchone()[0]
        low=c.execute("SELECT COUNT(*) FROM products WHERE active=1 AND stock<=min_stock").fetchone()[0]; cust=c.execute("SELECT COUNT(*) FROM customers").fetchone()[0]; prod=c.execute("SELECT COUNT(*) FROM products WHERE active=1").fetchone()[0]
        rows=c.execute("SELECT s.invoice_no,COALESCE(cu.name,'Walk-in'),s.subtotal,s.discount,s.tax,s.total FROM sales s LEFT JOIN customers cu ON cu.id=s.customer_id ORDER BY s.id DESC LIMIT 100").fetchall(); c.close()
        for k,v in [("sales",f"₹{s['total']:.2f}"),("bills",s["n"]),("profit",f"₹{profit:.2f}"),("low",low),("cust",cust),("prod",prod)]:self.kpis[k].setText(str(v))
        self.rt.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for j,v in enumerate(row):self.rt.setItem(r,j,QTableWidgetItem(str(v)))

    def ai_insights(self):
        c=self.db(); rows=c.execute("SELECT p.name,SUM(si.quantity) q,SUM(si.line_total) v FROM sale_items si JOIN products p ON p.id=si.product_id JOIN sales s ON s.id=si.sale_id WHERE s.status='COMPLETED' GROUP BY p.id ORDER BY q DESC LIMIT 10").fetchall()
        low=c.execute("SELECT name,stock,min_stock FROM products WHERE active=1 AND stock<=min_stock ORDER BY stock").fetchall(); exp=c.execute("SELECT name,expiry_date FROM products WHERE active=1 AND expiry_date<>'' ORDER BY expiry_date LIMIT 10").fetchall()
        total=c.execute("SELECT COALESCE(SUM(total),0) FROM sales WHERE date(created_at)>=date('now','-30 day') AND status='COMPLETED'").fetchone()[0]; bills=c.execute("SELECT COUNT(*) FROM sales WHERE date(created_at)>=date('now','-30 day') AND status='COMPLETED'").fetchone()[0]; c.close()
        lines=["◆ RUBIX$ SALES INSIGHTS","="*50,f"30-day revenue: ₹{total:.2f}",f"30-day bills: {bills}",""]
        if rows:
            lines.append("🏆 Top products:")
            for i,r in enumerate(rows,1):lines.append(f"{i}. {r['name']} — {r['q']:.0f} units / ₹{r['v']:.2f}")
        if low:
            lines += ["","⚠️ Smart reorder recommendations:"]
            for r in low:lines.append(f"• {r['name']}: stock {r['stock']:.0f}; recommended reorder ≈ {max(0,r['min_stock']*3-r['stock']):.0f}")
        lines += ["","📌 Recommended actions:","• Prioritize fast-moving products for replenishment.","• Review slow-moving items for bundles or discounts.","• Monitor unusually high discounts and refunds in Audit Logs.","• Use customer points and membership to improve repeat purchases."]
        self.ai.setPlainText("\n".join(lines))

    def export_csv(self):
        c=self.db(); rows=c.execute("SELECT invoice_no,subtotal,discount,tax,total,payment_method,status,created_at FROM sales ORDER BY id DESC").fetchall(); c.close()
        out=self.db_path.parent/"exports"/"sales_report.csv"; out.parent.mkdir(exist_ok=True)
        with open(out,"w",newline="",encoding="utf-8-sig") as f:
            w=csv.writer(f); w.writerow(rows[0].keys() if rows else ["invoice_no","subtotal","discount","tax","total","payment_method","status","created_at"]); w.writerows([tuple(r) for r in rows])
        QMessageBox.information(self,"Exported",str(out))
    def data_center(self):
        """Export every available business dataset to CSV, Excel, PDF or Word."""
        if self.current_role not in ("Admin", "Accountant"):
            return QMessageBox.warning(self,"Access denied","Only Admin or Accountant can export business data.")
        fmt,ok=QInputDialog.getItem(self,"DATA CENTER","Choose export format:", ["Excel workbook (.xlsx)","CSV files (one per dataset)","PDF report (.pdf)","Word document (.docx)"],0,False)
        if not ok: return
        folder=QFileDialog.getExistingDirectory(self,"Choose export folder",str(self.db_path.parent/"exports"))
        if not folder: return
        outdir=Path(folder); outdir.mkdir(parents=True,exist_ok=True)
        c=self.db()
        tables=[r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").fetchall()]
        datasets=[]
        for table in tables:
            # SQLite table names originate from sqlite_master, quoted defensively.
            rows=c.execute('SELECT * FROM "'+table.replace('"','""')+'"').fetchall()
            cols=[d[0] for d in c.execute('SELECT * FROM "'+table.replace('"','""')+'" LIMIT 0').description or []]
            datasets.append((table,cols,[tuple(row) for row in rows]))
        c.close()
        stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
        try:
            if fmt.startswith("CSV"):
                for name,cols,rows in datasets:
                    with open(outdir/f"{name}_{stamp}.csv","w",newline="",encoding="utf-8-sig") as f:
                        w=csv.writer(f); w.writerow(cols); w.writerows(rows)
                target=outdir
            elif fmt.startswith("Excel"):
                from openpyxl import Workbook
                wb=Workbook(); wb.remove(wb.active)
                for name,cols,rows in datasets:
                    ws=wb.create_sheet(name[:31]); ws.append(cols)
                    for row in rows: ws.append([str(v) if isinstance(v,bytes) else v for v in row])
                    ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
                target=outdir/f"RUBIX_ALL_DATA_{stamp}.xlsx"; wb.save(target)
            elif fmt.startswith("PDF"):
                from reportlab.lib import colors
                from reportlab.lib.pagesizes import landscape, A4
                from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
                from reportlab.lib.styles import getSampleStyleSheet
                target=outdir/f"RUBIX_ALL_DATA_{stamp}.pdf"; doc=SimpleDocTemplate(str(target),pagesize=landscape(A4))
                styles=getSampleStyleSheet(); story=[Paragraph("RUBIX POS — BUSINESS DATA EXPORT",styles['Title']),Paragraph(datetime.now().strftime("Generated %d-%m-%Y %H:%M"),styles['Normal']),Spacer(1,12)]
                for name,cols,rows in datasets:
                    story.append(Paragraph(name.replace('_',' ').title(),styles['Heading2']))
                    data=[[str(x) for x in cols]]+[[str(x)[:120] if x is not None else '' for x in row] for row in rows[:5000]]
                    if not data[0]: continue
                    widths=[max(45,720/max(1,len(cols)))]*len(cols)
                    t=Table(data,repeatRows=1,colWidths=widths); t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#6b4226')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('GRID',(0,0),(-1,-1),.25,colors.grey),('FONTSIZE',(0,0),(-1,-1),7),('VALIGN',(0,0),(-1,-1),'TOP')]))
                    story.extend([t,Spacer(1,10)])
                doc.build(story)
            else:
                from docx import Document
                target=outdir/f"RUBIX_ALL_DATA_{stamp}.docx"; doc=Document(); doc.add_heading("RUBIX POS — BUSINESS DATA EXPORT",0); doc.add_paragraph(datetime.now().strftime("Generated %d-%m-%Y %H:%M"))
                for name,cols,rows in datasets:
                    doc.add_heading(name.replace('_',' ').title(),level=1); table=doc.add_table(rows=1, cols=max(1,len(cols))); table.style='Table Grid'
                    for i,v in enumerate(cols): table.rows[0].cells[i].text=str(v)
                    for row in rows[:2000]:
                        cells=table.add_row().cells
                        for i,v in enumerate(row): cells[i].text='' if v is None else str(v)[:500]
                doc.save(target)
            self.log("DATA_EXPORT",f"format={fmt}; datasets={len(datasets)}")
            QMessageBox.information(self,"Data export complete",f"Export finished. Datasets: {len(datasets)}\nSaved to: {target}")
        except Exception as e:
            QMessageBox.critical(self,"Export failed",f"Could not export data: {e}")

    def auto_backup(self):
        try:
            backup_database(self.db_path, self.backup_dir)
        except Exception as exc:
            # Keep the POS usable; report the issue without interrupting every transaction.
            self.statusBar().showMessage(f"Automatic backup failed: {exc}", 10000)

    def closeEvent(self, event):
        try:
            backup_database(self.db_path, self.backup_dir)
        except Exception:
            pass
        event.accept()
    def save_employee(self):
        if self.current_role != "Admin": return QMessageBox.warning(self,"Access denied","Only Admin can manage other users.")
        if not self.en.text().strip() or not self.eu.text().strip() or not self.epw.text():
            return QMessageBox.warning(self,"Employee","Name, username and password are required.")
        problem=password_problem(self.epw.text(),self.eu.text().strip())
        if problem: return QMessageBox.warning(self,"Employee",problem)
        c=self.db()
        try:
            if self.er.currentText()=="Admin" and c.execute("SELECT COUNT(*) FROM employees WHERE role='Admin' AND active=1").fetchone()[0]>=1:
                return QMessageBox.warning(self,"Admin limit","Only one active Admin account is allowed. Add Manager, Cashier or Accountant instead.")
            c.execute("INSERT INTO employees(name,username,role,phone,password_hash,created_at) VALUES(?,?,?,?,?,?)",(self.en.text().strip(),self.eu.text().strip(),self.er.currentText(),self.eph.text().strip(),hash_password(self.epw.text()),datetime.now().isoformat(timespec="seconds"))); c.commit(); self.epw.clear(); self.refresh_employees(); QMessageBox.information(self,"User created","User account created with the password you entered.")
        except Exception as e:QMessageBox.warning(self,"Employee",str(e))
        finally: c.close()
    def clear_user_form(self):
        for w in (self.en,self.eu,self.eph,self.epw): w.clear()
        self.emt.clearSelection()
    def user_selected(self):
        r=self.emt.currentRow()
        if r<0 or not self.emt.item(r,0): return
        self.en.setText(self.emt.item(r,1).text()); self.eu.setText(self.emt.item(r,2).text()); self.er.setCurrentText(self.emt.item(r,3).text()); self.eph.setText(self.emt.item(r,4).text()); self.epw.clear()
    def update_user(self):
        if self.current_role!="Admin": return QMessageBox.warning(self,"Access denied","Only Admin can edit users.")
        uid=self._selected_employee_id()
        if uid is None: return
        if not self.en.text().strip(): return QMessageBox.warning(self,"Employee","Name is required.")
        c=self.db()
        try:
            row=c.execute("SELECT role,active,username FROM employees WHERE id=?",(uid,)).fetchone(); new_role=self.er.currentText()
            if row and new_role!=row["role"]:
                if row["username"].casefold()==self.current_user.casefold(): return QMessageBox.warning(self,"Users & Access","You cannot change your own role.")
                if new_role=="Admin" and c.execute("SELECT COUNT(*) FROM employees WHERE role='Admin' AND active=1 AND id<>?",(uid,)).fetchone()[0]>=1: return QMessageBox.warning(self,"Admin limit","Only one active Admin account is allowed.")
                if row["role"]=="Admin" and c.execute("SELECT COUNT(*) FROM employees WHERE role='Admin' AND active=1 AND id<>?",(uid,)).fetchone()[0]<1: return QMessageBox.warning(self,"Admin required","The only Admin cannot be changed.")
            c.execute("UPDATE employees SET name=?,phone=?,role=? WHERE id=?",(self.en.text().strip(),self.eph.text().strip(),new_role,uid)); c.commit(); self.log("USER_UPDATED",f"user_id={uid}")
            self.refresh_employees(); QMessageBox.information(self,"User updated","User details updated. (Use RESET USERNAME / RESET PASSWORD to change login details.)")
        finally: c.close()
    def delete_user(self):
        if self.current_role!="Admin": return QMessageBox.warning(self,"Access denied","Only Admin can delete users.")
        uid=self._selected_employee_id()
        if uid is None: return
        c=self.db(); row=c.execute("SELECT username,role FROM employees WHERE id=?",(uid,)).fetchone()
        if not row: c.close(); return
        if row["username"].casefold()==self.current_user.casefold() or row["role"]=="Admin":
            c.close(); return QMessageBox.warning(self,"Users & Access","The Admin account / your own account cannot be deleted.")
        if not self._confirm("Delete user",f"Delete user '{row['username']}'? Their old bills stay in reports."): c.close(); return
        self._safety_backup(); c.execute("DELETE FROM employees WHERE id=?",(uid,)); c.commit(); c.close(); self.log("USER_DELETED",f"user_id={uid}"); self.clear_user_form(); self.refresh_employees()
    def _selected_employee_id(self):
        row=self.emt.currentRow()
        if row < 0 or not self.emt.item(row,0):
            QMessageBox.warning(self,"Users & Access","Select a user first.")
            return None
        return int(self.emt.item(row,0).text())

    def reset_username(self):
        if self.current_role != "Admin":
            return QMessageBox.warning(self,"Access denied","Only Admin can change usernames.")
        uid=self._selected_employee_id()
        if uid is None: return
        c=self.db(); row=c.execute("SELECT username FROM employees WHERE id=?",(uid,)).fetchone(); c.close()
        if not row: return
        old_name=row["username"]
        new_name,ok=QInputDialog.getText(self,"Reset Username",f"New username for {old_name}:")
        if not ok: return
        new_name=new_name.strip()
        if len(new_name)<3:
            return QMessageBox.warning(self,"Username","Username must contain at least 3 characters.")
        c=self.db()
        try:
            c.execute("UPDATE employees SET username=? WHERE id=?",(new_name,uid)); c.commit()
            self.log("USERNAME_RESET",f"user_id={uid}")
            QMessageBox.information(self,"Username Updated","Username updated. Use the new username at next sign-in.")
            self.refresh_employees()
            if old_name.casefold() == self.current_user.casefold():
                self.current_user=new_name
        except sqlite3.IntegrityError:
            QMessageBox.warning(self,"Username","That username is already in use.")
        finally: c.close()

    def force_password_change(self):
        """Shown right after the first login with the factory password. Returns False if the user gives up."""
        uid=self._current_employee_id()
        if uid is None: return True
        QMessageBox.information(self,"Set a new password","You are using the factory password.\nFor security, please choose your own password now.")
        while True:
            pw,ok=QInputDialog.getText(self,"New password","New password (min 8 characters, letters + numbers):",QLineEdit.Password)
            if not ok: return False
            problem=password_problem(pw,self.current_user)
            if problem: QMessageBox.warning(self,"Password",problem); continue
            pw2,ok=QInputDialog.getText(self,"Confirm password","Type the new password again:",QLineEdit.Password)
            if not ok: return False
            if pw!=pw2: QMessageBox.warning(self,"Password","The two passwords do not match."); continue
            c=self.db(); c.execute("UPDATE employees SET password_hash=? WHERE id=?",(hash_password(pw),uid)); c.commit(); c.close()
            self.log("PASSWORD_CHANGED","first login"); QMessageBox.information(self,"Password","Password changed. Use it next time you sign in."); return True

    def change_my_password(self):
        uid=self._current_employee_id()
        c=self.db(); row=c.execute("SELECT password_hash FROM employees WHERE id=?",(uid,)).fetchone(); c.close()
        if not row: return
        old,ok=QInputDialog.getText(self,"Change password","Current password:",QLineEdit.Password)
        if not ok: return
        if not verify_password(old,row["password_hash"])[0]: return QMessageBox.warning(self,"Password","Current password is wrong.")
        pw,ok=QInputDialog.getText(self,"Change password","New password (min 8 characters, letters + numbers):",QLineEdit.Password)
        if not ok: return
        problem=password_problem(pw,self.current_user)
        if problem: return QMessageBox.warning(self,"Password",problem)
        pw2,ok=QInputDialog.getText(self,"Change password","Type the new password again:",QLineEdit.Password)
        if not ok: return
        if pw!=pw2: return QMessageBox.warning(self,"Password","The two passwords do not match.")
        c=self.db(); c.execute("UPDATE employees SET password_hash=? WHERE id=?",(hash_password(pw),uid)); c.commit(); c.close()
        self.log("PASSWORD_CHANGED","self"); QMessageBox.information(self,"Password","Password changed.")

    def _current_employee_id(self):
        c=self.db(); row=c.execute("SELECT id FROM employees WHERE lower(username)=lower(?) LIMIT 1",(self.current_user,)).fetchone(); c.close()
        return row["id"] if row else None

    def reset_user_password(self):
        if self.current_role != "Admin":
            return QMessageBox.warning(self,"Access denied","Only Admin can reset user passwords.")
        uid=self._selected_employee_id()
        if uid is None: return
        c=self.db(); row=c.execute("SELECT id,username,name FROM employees WHERE id=?",(uid,)).fetchone(); c.close()
        if not row: return
        new_pw,ok=QInputDialog.getText(self,"Reset Password",f"New password for {row['username']}:" ,QLineEdit.Password)
        if not ok: return
        problem=password_problem(new_pw,row["username"])
        if problem: return QMessageBox.warning(self,"Password",problem)
        c=self.db(); c.execute("UPDATE employees SET password_hash=? WHERE id=?",(hash_password(new_pw),uid)); c.commit(); c.close()
        self.log("PASSWORD_RESET",f"user_id={uid}"); QMessageBox.information(self,"Password Reset","Password updated successfully.")

    def toggle_user(self):
        if self.current_role != "Admin":
            return QMessageBox.warning(self,"Access denied","Only Admin can enable or disable users.")
        uid=self._selected_employee_id()
        if uid is None: return
        c=self.db(); row=c.execute("SELECT username,role,active FROM employees WHERE id=?",(uid,)).fetchone()
        if not row: c.close(); return
        if row["username"] == self.current_user:
            c.close(); return QMessageBox.warning(self,"Users & Access","You cannot disable your own account while signed in.")
        new_state=0 if row["active"] else 1
        if row["role"]=="Admin" and new_state==0:
            active_admins=c.execute("SELECT COUNT(*) FROM employees WHERE role='Admin' AND active=1").fetchone()[0]
            if active_admins<=1:
                c.close(); return QMessageBox.warning(self,"Admin required","The only active Admin cannot be disabled.")
        if row["role"]=="Admin" and new_state==1:
            active_admins=c.execute("SELECT COUNT(*) FROM employees WHERE role='Admin' AND active=1 AND id<>?",(uid,)).fetchone()[0]
            if active_admins>=1:
                c.close(); return QMessageBox.warning(self,"Admin limit","Only one active Admin account is allowed. Disable the other Admin first.")
        c.execute("UPDATE employees SET active=? WHERE id=?",(new_state,uid)); c.commit(); c.close()
        self.log("USER_STATUS_CHANGED",f"user_id={uid},active={new_state}"); self.refresh_employees()

    def refresh_employees(self):
        c=self.db(); rows=c.execute("SELECT id,name,username,role,phone,active FROM employees ORDER BY id").fetchall(); c.close(); self.emt.setRowCount(len(rows))
        for r,row in enumerate(rows):
            for j,v in enumerate(row):self.emt.setItem(r,j,QTableWidgetItem(str(v)))
