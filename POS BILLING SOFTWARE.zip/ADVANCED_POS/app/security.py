"""Password hashing helpers (PBKDF2-HMAC-SHA256 with a random per-user salt).

Stored format:  pbkdf2_sha256$<iterations>$<salt hex>$<hash hex>
Older databases stored an unsalted SHA-256 hex digest. Those are still accepted
at login and are silently upgraded to PBKDF2 the first time the user signs in.
"""
import hashlib, hmac, os

ITERATIONS = 240_000
PREFIX = "pbkdf2_sha256"
DEFAULT_ADMIN_PASSWORD = "A1B2C3D4"   # factory password; users are forced to change it


def hash_password(password: str, iterations: int = ITERATIONS) -> str:
    salt = os.urandom(16)
    dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return f"{PREFIX}${iterations}${salt.hex()}${dk.hex()}"


def verify_password(password: str, stored: str):
    """Return (is_valid, needs_upgrade)."""
    stored = stored or ""
    if stored.startswith(PREFIX + "$"):
        try:
            _, iters, salt_hex, hash_hex = stored.split("$")
            dk = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), int(iters))
            return hmac.compare_digest(dk.hex(), hash_hex), int(iters) < ITERATIONS
        except (ValueError, TypeError):
            return False, False
    legacy = hashlib.sha256(password.encode("utf-8")).hexdigest()
    ok = bool(stored) and hmac.compare_digest(legacy, stored)
    return ok, ok


def is_default_password(stored: str) -> bool:
    return verify_password(DEFAULT_ADMIN_PASSWORD, stored)[0]


def password_problem(password: str, username: str = ""):
    """Return a message when the password is too weak, else None."""
    if len(password) < 8:
        return "Password must contain at least 8 characters."
    if password.isdigit() or password.isalpha():
        return "Use a mix of letters and numbers."
    if password == DEFAULT_ADMIN_PASSWORD or (username and password.casefold() == username.casefold()):
        return "Choose a different password."
    return None
