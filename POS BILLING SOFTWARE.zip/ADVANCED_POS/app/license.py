"""Machine-bound RUBIX POS activation.

This offline mode permits the same owner activation credentials on separate PCs,
while each installation gets its own machine-bound license file. For robust
commercial anti-tamper protection, issue signed licenses from a hosted API; a
secret embedded in a desktop app can never be considered fully secret.
"""
from datetime import datetime, timedelta
from pathlib import Path
import hashlib, hmac, json, os, platform, uuid

ACTIVATE_KEY = "SEDNEYSWEETNEY@984"
ACTIVATOR = "SABARI"
APP_DATA = Path(os.environ.get("APPDATA", str(Path.home()))) / "RUBIXPOS"
LICENSE_PATH = APP_DATA / "license.json"
ATTEMPTS_PATH = APP_DATA / "activation_attempts.json"
# Integrity check only; hosted signing is required for strong commercial security.
_LOCAL_INTEGRITY_KEY = b"RUBIX-POS-local-integrity-v2-rotate-for-release"

def machine_id():
    raw = "|".join([platform.system(), platform.machine(), hex(uuid.getnode())])
    return hashlib.sha256(raw.encode("utf-8")).hexdigest().upper()

def _signature(payload):
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hmac.new(_LOCAL_INTEGRITY_KEY, raw, hashlib.sha256).hexdigest()

def _read_json(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return {}

def load_license():
    return _read_json(LICENSE_PATH)

def is_activated():
    data = load_license()
    payload = data.get("payload")
    if not isinstance(payload, dict):
        return False
    return (payload.get("machine_id") == machine_id()
            and payload.get("activated") is True
            and isinstance(data.get("signature"), str)
            and hmac.compare_digest(data["signature"], _signature(payload)))

def activate(key, activator):
    # Basic local throttling against accidental/brute-force repeated attempts.
    APP_DATA.mkdir(parents=True, exist_ok=True)
    attempts = _read_json(ATTEMPTS_PATH)
    now = datetime.now()
    try:
        start = datetime.fromisoformat(attempts.get("window_start", ""))
        count = int(attempts.get("count", 0))
        if now - start > timedelta(minutes=10):
            start, count = now, 0
    except (ValueError, TypeError):
        start, count = now, 0
    if count >= 8:
        return False, "Too many attempts. Please wait 10 minutes and try again."
    valid_key = hmac.compare_digest(key.strip(), ACTIVATE_KEY)
    valid_activator = hmac.compare_digest(activator.strip().upper(), ACTIVATOR)
    if not (valid_key and valid_activator):
        ATTEMPTS_PATH.write_text(json.dumps({"window_start": start.isoformat(), "count": count + 1}), encoding="utf-8")
        return False, "Invalid activation key or activator name."
    # The same owner key may be used on different PCs; each PC receives a separate local binding.
    payload = {"activated": True, "machine_id": machine_id(),
               "activated_at": now.isoformat(timespec="seconds"), "license_version": 2}
    LICENSE_PATH.write_text(json.dumps({"payload": payload, "signature": _signature(payload)}, indent=2), encoding="utf-8")
    try:
        ATTEMPTS_PATH.unlink(missing_ok=True)
    except OSError:
        pass
    return True, "This PC has been activated successfully."

def validate_local_license(license_data):
    if not license_data:
        return False, "No license configured"
    expiry = license_data.get("expiry")
    if expiry:
        try:
            if datetime.now().date() > datetime.fromisoformat(expiry).date():
                return False, "License expired"
        except ValueError:
            return False, "Invalid expiry"
    return True, "License OK"
