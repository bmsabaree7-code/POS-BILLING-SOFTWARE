"""Business logic kept separate from the Qt screens so it can be tested on its own."""
import csv
from datetime import datetime


def _now():
    return datetime.now().isoformat(timespec="seconds")


def _num(v, default=0.0):
    if v is None or str(v).strip() == "":
        return float(default)
    try:
        return float(str(v).replace(",", "").replace("₹", "").strip())
    except ValueError:
        raise ValueError(f"'{v}' is not a number")


def apply_discount(base, value, percent=False):
    """Discount amount for a bill, never more than the bill itself."""
    base = max(0.0, float(base)); value = max(0.0, float(value))
    amount = base * min(value, 100.0) / 100.0 if percent else value
    return round(min(amount, base), 2)


def split_payment(total, first_method, first_amount, second_method):
    first_amount = round(max(0.0, min(float(first_amount), float(total))), 2)
    rest = round(float(total) - first_amount, 2)
    parts = [(first_method, first_amount)]
    if rest > 0:
        parts.append((second_method, rest))
    return [p for p in parts if p[1] > 0]


def record_purchase(con, supplier_id, items, payment_method="Cash", invoice_no=None):
    """Save a purchase bill, raise stock, update buy price, and add credit purchases to the supplier balance.
    items: list of (product_id, quantity, unit_cost)."""
    if not items:
        raise ValueError("No items to purchase.")
    now = _now(); invoice_no = invoice_no or "PUR-" + datetime.now().strftime("%Y%m%d-%H%M%S-%f")[:-3]
    subtotal = sum(q * cst for _, q, cst in items)
    pid = con.execute("INSERT INTO purchases(invoice_no,supplier_id,subtotal,tax,total,payment_method,created_at) VALUES(?,?,?,?,?,?,?)",
                      (invoice_no, supplier_id, subtotal, 0, subtotal, payment_method, now)).lastrowid
    for product_id, qty, cost in items:
        if qty <= 0:
            raise ValueError("Quantity must be more than 0.")
        con.execute("INSERT INTO purchase_items(purchase_id,product_id,quantity,cost,line_total) VALUES(?,?,?,?,?)", (pid, product_id, qty, cost, qty * cost))
        con.execute("UPDATE products SET stock=stock+?,purchase_price=?,updated_at=? WHERE id=?", (qty, cost, now, product_id))
        con.execute("INSERT INTO stock_movements(product_id,type,quantity,reference,created_at) VALUES(?,?,?,?,?)", (product_id, "PURCHASE", qty, invoice_no, now))
    if supplier_id and payment_method == "Credit":
        con.execute("UPDATE suppliers SET balance=balance+? WHERE id=?", (subtotal, supplier_id))
    return invoice_no, subtotal


def pay_supplier(con, supplier_id, amount):
    row = con.execute("SELECT balance FROM suppliers WHERE id=?", (supplier_id,)).fetchone()
    if not row:
        raise ValueError("Supplier not found.")
    amount = min(float(amount), float(row["balance"]))
    con.execute("UPDATE suppliers SET balance=balance-? WHERE id=?", (amount, supplier_id))
    con.execute("INSERT INTO expenses(category,description,amount,payment_method,created_at) VALUES(?,?,?,?,?)",
                ("Supplier Payment", f"Payment to supplier #{supplier_id}", amount, "Cash", _now()))
    return amount


def _rows(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        for i, row in enumerate(csv.DictReader(f), start=2):
            yield i, {(k or "").strip().lower().replace(" ", "_"): (v or "").strip() for k, v in row.items()}


def import_products_csv(con, path):
    """Add new products / update existing ones (matched on barcode). Returns (added, updated, errors)."""
    added = updated = 0; errors = []; now = _now()
    for line, r in _rows(path):
        try:
            if not r.get("name"):
                raise ValueError("name is missing")
            bc = r.get("barcode") or "AUTO" + datetime.now().strftime("%Y%m%d%H%M%S%f")
            vals = (r["name"], r.get("category", ""), r.get("unit") or "pcs", _num(r.get("purchase_price")), _num(r.get("selling_price")),
                    _num(r.get("stock")), _num(r.get("min_stock"), 5), _num(r.get("tax_rate")), r.get("expiry_date", ""))
            ex = con.execute("SELECT id FROM products WHERE barcode=? AND active=1", (bc,)).fetchone()
            if ex:
                con.execute("UPDATE products SET name=?,category=?,unit=?,purchase_price=?,selling_price=?,stock=?,min_stock=?,tax_rate=?,expiry_date=?,updated_at=? WHERE id=?", vals + (now, ex["id"])); updated += 1
            else:
                con.execute("INSERT INTO products(name,category,unit,purchase_price,selling_price,stock,min_stock,tax_rate,expiry_date,barcode,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", vals + (bc, now, now)); added += 1
        except Exception as e:
            errors.append(f"Line {line}: {e}")
    return added, updated, errors


def import_customers_csv(con, path):
    added = updated = 0; errors = []
    for line, r in _rows(path):
        try:
            if not r.get("name"):
                raise ValueError("name is missing")
            ex = con.execute("SELECT id FROM customers WHERE phone=? AND phone<>''", (r.get("phone", ""),)).fetchone()
            if ex:
                con.execute("UPDATE customers SET name=?,email=?,address=? WHERE id=?", (r["name"], r.get("email", ""), r.get("address", ""), ex["id"])); updated += 1
            else:
                con.execute("INSERT INTO customers(name,phone,email,address,created_at) VALUES(?,?,?,?,?)", (r["name"], r.get("phone", ""), r.get("email", ""), r.get("address", ""), _now())); added += 1
        except Exception as e:
            errors.append(f"Line {line}: {e}")
    return added, updated, errors
