
import sqlite3, shutil, os, tempfile
from pathlib import Path
from datetime import datetime

def connect(db_path):
    con = sqlite3.connect(str(db_path))
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    return con

def init_db(db_path):
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    con=connect(db_path)
    con.executescript("""
    CREATE TABLE IF NOT EXISTS branches(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,code TEXT UNIQUE NOT NULL,address TEXT DEFAULT '',active INTEGER DEFAULT 1);
    CREATE TABLE IF NOT EXISTS employees(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,username TEXT UNIQUE NOT NULL,role TEXT NOT NULL,phone TEXT DEFAULT '',active INTEGER DEFAULT 1,password_hash TEXT DEFAULT '',created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS products(
      id INTEGER PRIMARY KEY AUTOINCREMENT, barcode TEXT UNIQUE NOT NULL,name TEXT NOT NULL,category TEXT DEFAULT '',
      unit TEXT DEFAULT 'pcs',purchase_price REAL DEFAULT 0,selling_price REAL DEFAULT 0,stock REAL DEFAULT 0,
      min_stock REAL DEFAULT 5,tax_rate REAL DEFAULT 0,expiry_date TEXT DEFAULT '',branch_id INTEGER DEFAULT 1,
      created_at TEXT NOT NULL,updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT DEFAULT '',email TEXT DEFAULT '',address TEXT DEFAULT '',balance REAL DEFAULT 0,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT DEFAULT '',email TEXT DEFAULT '',address TEXT DEFAULT '',points REAL DEFAULT 0,membership TEXT DEFAULT 'Regular',credit_balance REAL DEFAULT 0,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS purchases(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_no TEXT UNIQUE NOT NULL,supplier_id INTEGER,subtotal REAL DEFAULT 0,tax REAL DEFAULT 0,total REAL DEFAULT 0,payment_method TEXT DEFAULT 'Cash',created_at TEXT NOT NULL,FOREIGN KEY(supplier_id) REFERENCES suppliers(id));
    CREATE TABLE IF NOT EXISTS purchase_items(id INTEGER PRIMARY KEY AUTOINCREMENT,purchase_id INTEGER NOT NULL,product_id INTEGER NOT NULL,quantity REAL NOT NULL,cost REAL NOT NULL,line_total REAL NOT NULL,FOREIGN KEY(purchase_id) REFERENCES purchases(id),FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY AUTOINCREMENT,invoice_no TEXT UNIQUE NOT NULL,customer_id INTEGER,employee_id INTEGER,branch_id INTEGER DEFAULT 1,subtotal REAL NOT NULL,discount REAL DEFAULT 0,tax REAL DEFAULT 0,total REAL NOT NULL,payment_method TEXT NOT NULL,status TEXT DEFAULT 'COMPLETED',created_at TEXT NOT NULL,FOREIGN KEY(customer_id) REFERENCES customers(id));
    CREATE TABLE IF NOT EXISTS sale_items(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER NOT NULL,product_id INTEGER NOT NULL,quantity REAL NOT NULL,price REAL NOT NULL,tax_rate REAL DEFAULT 0,line_total REAL NOT NULL,FOREIGN KEY(sale_id) REFERENCES sales(id),FOREIGN KEY(product_id) REFERENCES products(id));
    CREATE TABLE IF NOT EXISTS returns(id INTEGER PRIMARY KEY AUTOINCREMENT,return_no TEXT UNIQUE NOT NULL,sale_id INTEGER,customer_id INTEGER,total REAL NOT NULL,reason TEXT DEFAULT '',created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY AUTOINCREMENT,category TEXT NOT NULL,description TEXT DEFAULT '',amount REAL NOT NULL,payment_method TEXT DEFAULT 'Cash',created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER,payment_method TEXT NOT NULL,amount REAL NOT NULL,reference TEXT DEFAULT '',created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS stock_movements(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id INTEGER NOT NULL,type TEXT NOT NULL,quantity REAL NOT NULL,reference TEXT DEFAULT '',created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT NOT NULL,message TEXT NOT NULL,read_flag INTEGER DEFAULT 0,created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT,action TEXT NOT NULL,details TEXT DEFAULT '',created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS app_meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS invoice_documents(id INTEGER PRIMARY KEY AUTOINCREMENT,sale_id INTEGER NOT NULL,invoice_no TEXT UNIQUE NOT NULL,pdf_path TEXT NOT NULL,pdf_blob BLOB NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(sale_id) REFERENCES sales(id));
    """)
    # Migrate older databases safely.
    emp_cols={r[1] for r in con.execute("PRAGMA table_info(employees)").fetchall()}
    if "password_hash" not in emp_cols:
        con.execute("ALTER TABLE employees ADD COLUMN password_hash TEXT DEFAULT ''")
    # Reporting columns: login session per bill and the buying cost captured at sale time (for exact profit).
    sales_cols={r[1] for r in con.execute("PRAGMA table_info(sales)").fetchall()}
    if "session_no" not in sales_cols:
        con.execute("ALTER TABLE sales ADD COLUMN session_no TEXT DEFAULT ''")
    item_cols={r[1] for r in con.execute("PRAGMA table_info(sale_items)").fetchall()}
    if "cost" not in item_cols:
        con.execute("ALTER TABLE sale_items ADD COLUMN cost REAL DEFAULT 0")
    prod_cols={r[1] for r in con.execute("PRAGMA table_info(products)").fetchall()}
    if "active" not in prod_cols:
        con.execute("ALTER TABLE products ADD COLUMN active INTEGER DEFAULT 1")
    now=datetime.now().isoformat(timespec="seconds")
    if con.execute("SELECT COUNT(*) FROM branches").fetchone()[0]==0:
        con.execute("INSERT INTO branches(name,code,address) VALUES(?,?,?)",("Main Branch","MAIN",""))
    from .security import hash_password
    # Remove legacy privileged roles; only Admin, Manager, Cashier, Accountant are supported.
    con.execute("UPDATE employees SET role='Admin' WHERE role='Super Admin'")
    con.execute("UPDATE employees SET role='Manager' WHERE role='Stock Manager'")
    # Seed the requested first account only when it does not exist. Never overwrite
    # credentials after setup, so an Admin can change username/password securely.
    rubix=con.execute("SELECT id FROM employees WHERE lower(username)=lower('RUBIX')").fetchone()
    if not rubix:
        con.execute("INSERT INTO employees(name,username,role,active,password_hash,created_at) VALUES(?,?,?,?,?,?)",
                    ("Admin","RUBIX","Admin",1,hash_password("A1B2C3D4"),now))
    else:
        # The activation-key owner is not an application role or employee name.
        con.execute("UPDATE employees SET name='Admin',role='Admin',active=1 WHERE id=?",(rubix["id"],))
    # Retire default legacy demo accounts so only the intended initial account remains.
    con.execute("DELETE FROM employees WHERE lower(username) IN ('admin','cashier') AND lower(username)<>lower('RUBIX')")
    # Normalize any other unsupported legacy role values.
    con.execute("UPDATE employees SET role='Manager' WHERE role NOT IN ('Admin','Manager','Cashier','Accountant')")
    if con.execute("SELECT COUNT(*) FROM products").fetchone()[0]==0:
        demo=[("8901000000012","Demo Cola","Beverages",25,40,50,5,5),("8901000000029","Demo Biscuit","Snacks",10,20,100,10,5),("8901000000036","Demo Soap","Personal Care",30,45,30,5,12)]
        con.executemany("INSERT INTO products(barcode,name,category,purchase_price,selling_price,stock,min_stock,tax_rate,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
            [(a,b,c,d,e,f,g,h,now,now) for a,b,c,d,e,f,g,h in demo])
    con.commit(); con.close()

def database_is_valid(db_path):
    """Return True only when SQLite can open the database and its integrity check passes."""
    db_path = Path(db_path)
    if not db_path.is_file() or db_path.stat().st_size == 0:
        return False
    try:
        con = sqlite3.connect(str(db_path), timeout=5)
        try:
            result = con.execute("PRAGMA integrity_check").fetchone()
            return bool(result and result[0] == "ok")
        finally:
            con.close()
    except sqlite3.Error:
        return False


def backup_database(db_path, backup_dir):
    """Create a consistent SQLite online backup and retain the newest 30 copies."""
    db_path, backup_dir = Path(db_path), Path(backup_dir)
    backup_dir.mkdir(parents=True, exist_ok=True)
    if not database_is_valid(db_path):
        return None
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    target = backup_dir / f"pos_backup_{stamp}.db"
    # SQLite's backup API safely includes committed data, unlike copying an open DB file.
    source = sqlite3.connect(str(db_path), timeout=10)
    destination = sqlite3.connect(str(target))
    try:
        source.backup(destination)
        destination.commit()
    except Exception:
        destination.close()
        source.close()
        target.unlink(missing_ok=True)
        raise
    finally:
        try: destination.close()
        except Exception: pass
        try: source.close()
        except Exception: pass
    if not database_is_valid(target):
        target.unlink(missing_ok=True)
        raise sqlite3.DatabaseError("Backup integrity check failed.")
    for old in sorted(backup_dir.glob("pos_backup_*.db"), key=lambda p: p.stat().st_mtime, reverse=True)[30:]:
        old.unlink(missing_ok=True)
    return target


def restore_latest_backup(db_path, backup_dir):
    """Restore the newest valid backup when the live DB is missing/corrupt."""
    db_path, backup_dir = Path(db_path), Path(backup_dir)
    candidates = sorted(backup_dir.glob("pos_backup_*.db"),
                        key=lambda p: p.stat().st_mtime, reverse=True)
    for candidate in candidates:
        if not database_is_valid(candidate):
            continue
        db_path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = db_path.with_suffix(".restore.tmp")
        try:
            src = sqlite3.connect(str(candidate), timeout=10)
            dst = sqlite3.connect(str(temp_path))
            try:
                src.backup(dst)
                dst.commit()
            finally:
                dst.close()
                src.close()
            if database_is_valid(temp_path):
                os.replace(temp_path, db_path)
                return candidate
        except (sqlite3.Error, OSError):
            pass
        finally:
            temp_path.unlink(missing_ok=True)
    return None
