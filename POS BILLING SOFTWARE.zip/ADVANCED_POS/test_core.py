from pathlib import Path
from tempfile import TemporaryDirectory
import hashlib
from app.security import hash_password, verify_password, is_default_password, password_problem
from app import services
from app.database import init_db, connect, backup_database, database_is_valid, restore_latest_backup

with TemporaryDirectory() as td:
    root=Path(td); db=root/'database'/'pos.db'; backups=root/'backups'
    init_db(db)
    con=connect(db)
    assert con.execute("SELECT COUNT(*) FROM employees").fetchone()[0] >= 1
    assert con.execute("SELECT COUNT(*) FROM products").fetchone()[0] >= 3
    r=con.execute("SELECT password_hash FROM employees WHERE username='RUBIX' AND role='Admin' AND active=1").fetchone()
    assert r and r[0].startswith('pbkdf2_sha256$') and verify_password('A1B2C3D4',r[0])[0] and is_default_password(r[0])
    assert con.execute("SELECT COUNT(*) FROM employees WHERE role='Super Admin'").fetchone()[0] == 0
    assert con.execute("SELECT COUNT(*) FROM employees WHERE role NOT IN ('Admin','Manager','Cashier','Accountant')").fetchone()[0] == 0
    con.execute("INSERT INTO employees(name,username,role,active,password_hash,created_at) VALUES(?,?,?,?,?,?)",('Cashier One','cashier1','Cashier',1,hashlib.sha256('OldPass123'.encode()).hexdigest(),'2026-10-10'))
    new_hash=hashlib.sha256('NewPass123'.encode()).hexdigest()
    con.execute("UPDATE employees SET password_hash=? WHERE lower(username)=lower(?)",(new_hash,'CASHIER1'))
    assert con.execute("SELECT 1 FROM employees WHERE lower(username)=lower(?) AND password_hash=? AND active=1",('cashier1',new_hash)).fetchone()
    con.execute("INSERT INTO customers(name,phone,created_at) VALUES(?,?,datetime('now'))",('Test Customer','9999999999'))
    assert con.execute("SELECT COUNT(*) FROM customers WHERE phone='9999999999'").fetchone()[0] == 1
    con.commit(); con.close()
    backup_database(db,backups)
    assert list(backups.glob('pos_backup_*.db'))
    assert database_is_valid(db)
    # Simulate a damaged live DB and verify the latest valid backup restores it.
    db.write_bytes(b"not a sqlite database")
    assert not database_is_valid(db)
    restored = restore_latest_backup(db, backups)
    assert restored is not None and database_is_valid(db)
    con=connect(db)
    assert con.execute("SELECT COUNT(*) FROM customers WHERE phone='9999999999'").fetchone()[0] == 1
    con.close()

# ---- security + business-logic tests
h=hash_password('Secret123'); assert h!=hash_password('Secret123')            # random salt
assert verify_password('Secret123',h)==(True,False) and not verify_password('wrong',h)[0]
legacy=hashlib.sha256(b'OldPass1').hexdigest(); assert verify_password('OldPass1',legacy)==(True,True)   # legacy accepted + flagged for upgrade
assert not verify_password('x','')[0] and not verify_password('x','pbkdf2_sha256$bad')[0]
assert password_problem('short1') and password_problem('abcdefgh') and password_problem('A1B2C3D4') is not None and password_problem('GoodPass9') is None
assert services.apply_discount(200,10,True)==20 and services.apply_discount(100,500)==100 and services.apply_discount(100,500,True)==100
assert services.split_payment(100,'Cash',30,'UPI')==[('Cash',30),('UPI',70)] and services.split_payment(100,'Cash',100,'UPI')==[('Cash',100)]
with TemporaryDirectory() as td:
    import csv
    db=Path(td)/'d'/'pos.db'; init_db(db); con=connect(db)
    con.execute("INSERT INTO suppliers(name,created_at) VALUES('S1','n')")
    pid=con.execute("SELECT id FROM products LIMIT 1").fetchone()[0]; before=con.execute("SELECT stock FROM products WHERE id=?",(pid,)).fetchone()[0]
    inv,total=services.record_purchase(con,1,[(pid,10,20.0)],'Credit'); assert total==200
    assert con.execute("SELECT stock FROM products WHERE id=?",(pid,)).fetchone()[0]==before+10
    assert con.execute("SELECT balance FROM suppliers WHERE id=1").fetchone()[0]==200
    assert services.pay_supplier(con,1,500)==200 and con.execute("SELECT balance FROM suppliers WHERE id=1").fetchone()[0]==0
    f=Path(td)/'p.csv'; f.write_text("barcode,name,category,selling_price,stock\nB1,Pen,Stat,10,5\nB1,Pen Blue,Stat,12,7\n,,x,1,1\nB2,Bad,Stat,abc,1\n",encoding='utf-8')
    a,u,e=services.import_products_csv(con,f); assert (a,u,len(e))==(1,1,2),(a,u,e)
    assert con.execute("SELECT name,selling_price,stock FROM products WHERE barcode='B1'").fetchone()[:]==('Pen Blue',12,7)
    f2=Path(td)/'c.csv'; f2.write_text("name,phone\nRam,9000000001\nRam K,9000000001\n",encoding='utf-8')
    a,u,e=services.import_customers_csv(con,f2); assert (a,u,len(e))==(1,1,0)
    con.commit(); con.close()
print('SECURITY_AND_SERVICE_TESTS_PASS')
print('CORE_TESTS_PASS')
